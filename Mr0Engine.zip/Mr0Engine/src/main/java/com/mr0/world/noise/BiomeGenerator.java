package mr0.world.noise;

import mr0.world.Biome;

/**
 * تولید بایوم با نویز.
 * تنظیم اصلی برای اندازه بایوم‌ها: BIOME_FREQUENCY
 */
public class BiomeGenerator {

    // ⭐⭐⭐ این عدد رو عوض کن تا اندازه بایوم‌ها تغییر کنه ⭐⭐⭐
    //   0.02  → بایوم‌های کوچیک و پراکنده
    //   0.01  → بایوم‌های کوچیک
    //   0.005 → بایوم‌های متوسط
    //   0.002 → بایوم‌های بزرگ   ← پیشنهاد من
    //   0.001 → بایوم‌های خیلی بزرگ (مثل Warhammer)
    private static final float BIOME_FREQUENCY = 0.002f;

    // مرز بین بایوم‌ها (روی خروجی نویز -1..1)
    // اگه می‌خوای یه بایوم بیشتر جا بگیره، مرز رو جابه‌جا کن
    private static final float SNOW_MAX    = -0.35f;  // n < 0.35- → SNOW
    private static final float PLAINS_MAX  = 0.10f;   // 0.35- تا 0.10 → PLAINS
    private static final float FOREST_MAX  = 0.45f;   // 0.10 تا 0.45 → FOREST
    // 0.45+ → DESERT

    private final FastNoiseLite noise;

    public BiomeGenerator(int seed) {
        noise = new FastNoiseLite(seed);
        noise.SetNoiseType(FastNoiseLite.NoiseType.OpenSimplex2);
        noise.SetFrequency(BIOME_FREQUENCY);
        // مهم: بدون Fractal → بایوم‌ها یکدست و بزرگ‌تر
        // اگه Fractal بذاری، بایوم‌ها لبه‌های ناهموار و کوچیک‌تر می‌شن
        noise.SetFractalType(FastNoiseLite.FractalType.None);
    }

    /** بایوم یک تایل مشخص */
    public Biome getBiomeAtTile(int tileX, int tileY) {
        float n = noise.GetNoise(tileX, tileY); // -1..1

        if (n < SNOW_MAX)   return Biome.SNOW;
        if (n < PLAINS_MAX) return Biome.PLAINS;
        if (n < FOREST_MAX) return Biome.FOREST;
        return Biome.DESERT;
    }

    /** اگه بعداً برای blend یا دکور خام نویز رو خواستی */
    public float getRawNoise(int tileX, int tileY) {
        return noise.GetNoise(tileX, tileY);
    }
}