package mr0.entity;

public class Animation {

    public final int frameCount;
    public final int frameWidth;
    public final int frameHeight;
    public final int columns;    // frames per row in spritesheet
    public final int rows;

    public final float frameDuration; // seconds per frame

    private float timer;
    private int currentFrame;
    private boolean loop;

    public Animation(int frameCount, int frameWidth, int frameHeight,
                     int columns, int rows, float fps, boolean loop) {
        this.frameCount = frameCount;
        this.frameWidth = frameWidth;
        this.frameHeight = frameHeight;
        this.columns = columns;
        this.rows = rows;
        this.frameDuration = 1f / fps;
        this.loop = loop;
    }

    public void update(float dt) {
        timer += dt;
        while (timer >= frameDuration) {
            timer -= frameDuration;
            currentFrame++;
            if (currentFrame >= frameCount) {
                if (loop) currentFrame = 0;
                else currentFrame = frameCount - 1;
            }
        }
    }

    public int getCurrentFrame() { return currentFrame; }

    /** UV coords of current frame inside spritesheet (0..1). */
    public float[] getUV() {
        int col = currentFrame % columns;
        int row = currentFrame / columns;

        float u0 = (float) col / columns;
        float v1 = 1f - (float) row / rows;
        float u1 = (float) (col + 1) / columns;
        float v0 = 1f - (float) (row + 1) / rows;

        return new float[]{ u0, v0, u1, v1 };
    }

    public void reset() {
        timer = 0;
        currentFrame = 0;
    }
}