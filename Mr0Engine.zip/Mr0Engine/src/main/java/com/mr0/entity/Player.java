package mr0.entity;

import mr0.world.World;

public class Player extends Entity {
    // توی Player.java اضافه کن
    public PlayerAppearance appearance = new PlayerAppearance();
    public static final float GRAVITY = 1800f;
    public static final float MAX_FALL = 1200f;
    public static final float MOVE_SPEED = 280f;
    public static final float JUMP_SPEED = 620f;
    // توی Player.java اضافه کن:
    public Inventory inventory = new Inventory();
    public final Animation animation;
    public boolean facingRight = true;
    public Player(float x, float y, Animation animation) {
        super(x, y, 40, 56); // ~2.5 tiles wide x 3.5 tiles tall
        this.animation = animation;
    }

    public void update(World world, float dt, boolean left, boolean right, boolean jump) {
        // 🌟 تشخیص جهت نگاه
        if (left && !right) facingRight = true;
        else if (right && !left) facingRight = false;

        float targetVx = 0;
        if (left)  targetVx -= MOVE_SPEED;
        if (right) targetVx += MOVE_SPEED;

        // snappy accel
        float accel = 2200f * dt;
        if (vx < targetVx) vx = Math.min(vx + accel, targetVx);
        else if (vx > targetVx) vx = Math.max(vx - accel, targetVx);

        if (jump && onGround) {
            vy = JUMP_SPEED;
            onGround = false;
        }

        physics(world, dt, GRAVITY, MAX_FALL);

        //animation.update(dt);
        if (animation != null) {
            animation.update(dt);
        }
    }
}