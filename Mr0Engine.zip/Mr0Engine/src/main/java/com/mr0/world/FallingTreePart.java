package mr0.world;

public class FallingTreePart {

    public final Tree.Type type;
    public final int sourceX;        // پیکسل
    public final int sourceY;        // پیکسل (بالای قسمت قطع شده)
    public final int width;
    public final int height;         // ارتفاع قسمتی که افتاده

    public float x, y;               // موقعیت فعلی
    public float rotation = 0f;      // درجه
    public float velocityY = 0f;
    public float velocityX = 0f;
    public float angularVelocity;

    public float life = 2.5f;        // ثانیه
    public boolean dead = false;

    public FallingTreePart(Tree tree, int cutHeightPixels) {
        this.type = tree.type;
        this.width = 64;
        this.height = tree.currentHeight - cutHeightPixels;

        int treePixelX = tree.baseX * World.tileSize();
        int treePixelY = tree.baseY * World.tileSize();

        this.sourceX = treePixelX - 32;
        this.sourceY = treePixelY - tree.currentHeight;

        this.x = sourceX;
        this.y = sourceY;

        // کمی به چپ یا راست هل بده
        this.velocityX = (float) ((Math.random() > 0.5 ? 1 : -1) * (40 + Math.random() * 60));
        this.angularVelocity = (float) ((Math.random() > 0.5 ? 1 : -1) * (90 + Math.random() * 120));
    }

    public void update(float dt) {
        if (dead) return;

        velocityY += 980f * dt;          // گرانش
        x += velocityX * dt;
        y += velocityY * dt;
        rotation += angularVelocity * dt;

        life -= dt;
        if (life <= 0) dead = true;
    }
}