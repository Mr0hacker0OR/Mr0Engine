package mr0.graphics;

import mr0.world.Block;
import mr0.world.BlockRegistry;
import mr0.world.Chunk;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import org.lwjgl.BufferUtils;

import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

public class ChunkMesh {

    private final int vaoFg;
    private final int vboFg;
    private final int eboFg;
    private int indexCountFg;

    private final int vaoWall;
    private final int vboWall;
    private final int eboWall;
    private int indexCountWall;

    public ChunkMesh() {

        // foreground
        vaoFg = glGenVertexArrays();
        vboFg = glGenBuffers();
        eboFg = glGenBuffers();
        setupVAO(vaoFg, vboFg, eboFg);

        // walls
        vaoWall = glGenVertexArrays();
        vboWall = glGenBuffers();
        eboWall = glGenBuffers();
        setupVAO(vaoWall, vboWall, eboWall);
    }

    private void setupVAO(int vao, int vbo, int ebo) {
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);

        int stride = 4 * Float.BYTES;
        glVertexAttribPointer(0, 2, GL_FLOAT, false, stride, 0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, stride, 2L * Float.BYTES);
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);
    }

    public void buildForeground(Chunk chunk) {
        int[] out = buildLayer(chunk, false);
        indexCountFg = out[0];
        upload(vboFg, eboFg, out[1], out[2]); // vertexOffset, indexOffset
    }

    public void buildWalls(Chunk chunk) {
        int[] out = buildLayer(chunk, true);
        indexCountWall = out[0];
        upload(vboWall, eboWall, out[1], out[2]);
    }

    /**
     * returns {indexCount, vertexOffset, indexOffset}
     */
    private int[] buildLayer(Chunk chunk, boolean walls) {

        int maxTiles = Chunk.SIZE * Chunk.SIZE;

        float[] vertices = new float[maxTiles * 16];
        int[] indices = new int[maxTiles * 6];

        int vo = 0, io = 0, vb = 0;

        int tileSize = BlockRegistry.TILE_SIZE;
        int cols = BlockRegistry.ATLAS_COLUMNS;
        int rows = BlockRegistry.ATLAS_ROWS;
        float atlasW = cols * tileSize;
        float atlasH = rows * tileSize;

        for (int y = 0; y < Chunk.SIZE; y++) {
            for (int x = 0; x < Chunk.SIZE; x++) {

                short id = walls ? chunk.getWall(x, y) : chunk.getBlock(x, y);
                if (id == 0) continue;

                // skip wall if foreground is solid (it would be hidden anyway)
                if (walls && chunk.getBlock(x, y) != 0) continue;

                Block block = BlockRegistry.get(id);
                if (block == null) continue;

                int tileIndex = block.sideTile;
                if (tileIndex < 0) continue;

                int col = tileIndex % cols;
                int row = tileIndex / cols;

                float u0 = (col * tileSize + 0.5f) / atlasW;
                float u1 = ((col + 1) * tileSize - 0.5f) / atlasW;
                float v0 = 1f - ((row + 1) * tileSize - 0.5f) / atlasH;
                float v1 = 1f - (row * tileSize + 0.5f) / atlasH;

                float px = chunk.getWorldX() + x * Chunk.TILE_SIZE;
                float py = chunk.getWorldY() + y * Chunk.TILE_SIZE;
                float sz = Chunk.TILE_SIZE;

                vertices[vo++] = px;       vertices[vo++] = py;
                vertices[vo++] = u0;       vertices[vo++] = v0;

                vertices[vo++] = px + sz;  vertices[vo++] = py;
                vertices[vo++] = u1;       vertices[vo++] = v0;

                vertices[vo++] = px + sz;  vertices[vo++] = py + sz;
                vertices[vo++] = u1;       vertices[vo++] = v1;

                vertices[vo++] = px;       vertices[vo++] = py + sz;
                vertices[vo++] = u0;       vertices[vo++] = v1;

                indices[io++] = vb;
                indices[io++] = vb + 1;
                indices[io++] = vb + 2;
                indices[io++] = vb + 2;
                indices[io++] = vb + 3;
                indices[io++] = vb;

                vb += 4;
            }
        }

        // Store buffers in temp fields (we need to upload separately)
        tempVertices = vertices;
        tempIndices = indices;
        tempVertexOffset = vo;
        tempIndexOffset = io;

        return new int[]{io, vo, io};
    }

    // temp for upload
    private float[] tempVertices;
    private int[] tempIndices;
    private int tempVertexOffset;
    private int tempIndexOffset;

    private void upload(int vbo, int ebo, int vertexOffset, int indexOffset) {

        FloatBuffer vb = BufferUtils.createFloatBuffer(Math.max(vertexOffset, 1));
        vb.put(tempVertices, 0, vertexOffset).flip();

        IntBuffer ib = BufferUtils.createIntBuffer(Math.max(indexOffset, 1));
        ib.put(tempIndices, 0, indexOffset).flip();

        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, vb, GL_DYNAMIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, ib, GL_DYNAMIC_DRAW);
    }

    public void renderWalls() {
        if (indexCountWall == 0) return;
        glBindVertexArray(vaoWall);
        glDrawElements(GL_TRIANGLES, indexCountWall, GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
    }

    public void renderForeground() {
        if (indexCountFg == 0) return;
        glBindVertexArray(vaoFg);
        glDrawElements(GL_TRIANGLES, indexCountFg, GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
    }

    public void destroy() {
        glDeleteBuffers(vboFg); glDeleteBuffers(eboFg); glDeleteVertexArrays(vaoFg);
        glDeleteBuffers(vboWall); glDeleteBuffers(eboWall); glDeleteVertexArrays(vaoWall);
    }
}