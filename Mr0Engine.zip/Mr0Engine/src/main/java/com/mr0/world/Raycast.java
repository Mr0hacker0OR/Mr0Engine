package mr0.world;

/**
 * Simple DDA raycast through the tile grid.
 * Returns the FIRST tile hit (solid block), or null.
 */
public class Raycast {

    public static class Hit {
        public final int tileX;
        public final int tileY;
        public final short blockId;

        public Hit(int tx, int ty, short id) {
            this.tileX = tx;
            this.tileY = ty;
            this.blockId = id;
        }
    }

    /**
     * @param tileSize  pixel size of one tile
     * @param maxDist   max distance in tiles
     */
    public static Hit cast(World world,
                           float pixelX, float pixelY,
                           float dirX, float dirY,
                           int tileSize,
                           int maxDist) {

        double len = Math.sqrt(dirX * dirX + dirY * dirY);
        if (len < 1e-6) return null;

        double dx = dirX / len;
        double dy = dirY / len;

        // start tile
        int tileX = (int) Math.floor(pixelX / tileSize);
        int tileY = (int) Math.floor(pixelY / tileSize);

        // position inside start tile in [0,1)
        double px = (pixelX / tileSize) - tileX;
        double py = (pixelY / tileSize) - tileY;

        int stepX = dx > 0 ? 1 : -1;
        int stepY = dy > 0 ? 1 : -1;

        double tDeltaX = dx != 0 ? Math.abs(1.0 / dx) : Double.MAX_VALUE;
        double tDeltaY = dy != 0 ? Math.abs(1.0 / dy) : Double.MAX_VALUE;

        double tMaxX = dx > 0 ? (1.0 - px) * tDeltaX : px * tDeltaX;
        double tMaxY = dy > 0 ? (1.0 - py) * tDeltaY : py * tDeltaY;

        for (int i = 0; i < maxDist * 3; i++) {

            short id = world.getBlockAtTile(tileX, tileY);

            if (id != 0) {
                return new Hit(tileX, tileY, id);
            }

            if (tMaxX < tMaxY) {
                tMaxX += tDeltaX;
                tileX += stepX;
            } else {
                tMaxY += tDeltaY;
                tileY += stepY;
            }

            // bound check: how far?
            double travelled = Math.max(
                    Math.abs((tileX - (pixelX / tileSize))),
                    Math.abs((tileY - (pixelY / tileSize)))
            );

            if (travelled > maxDist) break;
        }

        return null;
    }
}