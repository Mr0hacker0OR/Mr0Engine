package mr0.entity;

import java.util.ArrayList;
import java.util.List;

public class Inventory {
    // حداکثر ۹ تا بلاک توی نوار (Hotbar)
    private final short[] slots = new short[9];
    private final int[] counts = new int[9];
    public int selectedSlot = 0;

    public Inventory() {
        for (int i = 0; i < 9; i++) slots[i] = 0; // 0 یعنی خالی
    }

    // اضافه کردن بلاک جدید
    public void addBlock(short blockId) {
        // اگه بلاک قبلا هست، تعدادش رو زیاد کن
        for (int i = 0; i < 9; i++) {
            if (slots[i] == blockId) {
                counts[i]++;
                return;
            }
        }
        // اگه نبود، توی اولین خونه خالی بذار
        for (int i = 0; i < 9; i++) {
            if (slots[i] == 0) {
                slots[i] = blockId;
                counts[i] = 1;
                return;
            }
        }
    }

    // کم کردن بلاک (موقع گذاشتن)
    public boolean removeBlock() {
        if (slots[selectedSlot] == 0) return false; // دست خالیه
        counts[selectedSlot]--;
        if (counts[selectedSlot] <= 0) {
            slots[selectedSlot] = 0; // خالی میشه
        }
        return true;
    }

    // گرفتن بلاک فعلی
    public short getCurrentBlock() {
        return slots[selectedSlot];
    }

    public short getSlot(int i) { return slots[i]; }
    public int getCount(int i) { return counts[i]; }
}