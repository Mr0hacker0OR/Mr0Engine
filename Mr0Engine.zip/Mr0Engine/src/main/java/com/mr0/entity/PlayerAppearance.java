package mr0.entity;

public class PlayerAppearance {
    public int baseId = 0;
    public int hairId = 0;
    public int hatId = -1;      // -1 یعنی هیچی (خالی)
    public int shirtId = 0;
    public int pantsId = 0;
    public int bootsId = 0;
    public int accId = -1;
}