#!/usr/bin/env python3
"""
Tree Atlas Generator for Mr0 2D Engine
--------------------------------------
Compatible with Python 3.7+
"""

from PIL import Image, ImageDraw
import json
import random
from pathlib import Path
from typing import List, Tuple  # <-- این خط مهمه

# ====================== CONFIG ======================
OUTPUT_DIR = Path("tree_output")
ATLAS_SIZE = 512
TREE_WIDTH = 64
TREE_HEIGHT = 96                  # می‌تونی بذاری 128
NUM_VARIANTS = 8
SEED = 42
# ====================================================

random.seed(SEED)

def clamp(v, lo, hi):
    return max(lo, min(hi, v))

def darker(color, amount=30):
    r, g, b, a = color
    return (clamp(r - amount, 0, 255),
            clamp(g - amount, 0, 255),
            clamp(b - amount, 0, 255), a)

def generate_oak_tree(width=TREE_WIDTH, height=TREE_HEIGHT, variant=0):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    trunk_colors = [
        (92, 64, 40, 255),
        (110, 78, 48, 255),
        (130, 95, 58, 255),
    ]
    leaf_colors = [
        (34, 85, 34, 255),
        (48, 110, 42, 255),
        (70, 140, 55, 255),
        (90, 160, 70, 255),
    ]

    cx = width // 2

    # Trunk
    trunk_width = random.randint(6, 9)
    trunk_height = random.randint(int(height * 0.35), int(height * 0.48))
    trunk_bottom = height - 2
    trunk_top = trunk_bottom - trunk_height

    for y in range(trunk_top, trunk_bottom + 1):
        tw = trunk_width - int((y - trunk_top) / trunk_height * 1.5)
        tw = max(4, tw)
        for x in range(cx - tw // 2, cx + tw // 2 + 1):
            c = trunk_colors[random.randint(0, 2)]
            if random.random() < 0.15:
                c = darker(c, 20)
            draw.point((x, y), fill=c)

    # Roots
    for dx in [-1, 1]:
        root_len = random.randint(4, 7)
        for i in range(root_len):
            x = cx + dx * (trunk_width // 2 + i // 2)
            y = trunk_bottom - i // 3
            if 0 <= x < width and 0 <= y < height:
                draw.point((x, y), fill=trunk_colors[1])
                draw.point((x, y + 1), fill=darker(trunk_colors[0]))

    # Canopy
    canopy_center_y = trunk_top - random.randint(8, 14)
    num_clusters = random.randint(5, 8)

    for i in range(num_clusters):
        offset_x = random.randint(-18, 18)
        offset_y = random.randint(-16, 10)
        cluster_x = cx + offset_x
        cluster_y = canopy_center_y + offset_y

        radius_x = random.randint(10, 16)
        radius_y = random.randint(9, 14)

        for dy in range(-radius_y, radius_y + 1):
            for dx in range(-radius_x, radius_x + 1):
                nx = dx / float(radius_x)
                ny = dy / float(radius_y)
                if nx*nx + ny*ny < 0.9 + random.uniform(-0.15, 0.1):
                    px = cluster_x + dx
                    py = cluster_y + dy
                    if 0 <= px < width and 0 <= py < height:
                        t = (dy + radius_y) / float(2 * radius_y)
                        if t < 0.3:
                            c = leaf_colors[3]
                        elif t < 0.55:
                            c = leaf_colors[2]
                        elif t < 0.8:
                            c = leaf_colors[1]
                        else:
                            c = leaf_colors[0]

                        if random.random() < 0.12:
                            c = darker(c, 25)
                        draw.point((px, py), fill=c)

    # Hanging leaves
    for _ in range(random.randint(3, 6)):
        bx = cx + random.randint(-20, 20)
        by = canopy_center_y + random.randint(5, 18)
        for i in range(random.randint(3, 6)):
            px = bx + random.randint(-1, 1)
            py = by + i
            if 0 <= px < width and 0 <= py < height:
                draw.point((px, py), fill=leaf_colors[1])

    return img


def generate_pine_tree(width=TREE_WIDTH, height=TREE_HEIGHT, variant=0):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    trunk_colors = [
        (70, 50, 35, 255),
        (90, 65, 40, 255),
        (105, 78, 48, 255),
    ]
    leaf_colors = [
        (20, 60, 35, 255),
        (30, 85, 45, 255),
        (45, 110, 55, 255),
        (60, 130, 70, 255),
    ]

    cx = width // 2

    trunk_width = random.randint(5, 7)
    trunk_height = int(height * 0.42)
    trunk_bottom = height - 2
    trunk_top = trunk_bottom - trunk_height

    for y in range(trunk_top, trunk_bottom + 1):
        tw = max(3, trunk_width - (y - trunk_top) // 12)
        for x in range(cx - tw // 2, cx + tw // 2 + 1):
            c = trunk_colors[random.randint(0, 2)]
            draw.point((x, y), fill=c)

    layers = random.randint(4, 6)
    base_y = trunk_top + 4

    for layer in range(layers):
        layer_y = base_y - layer * (height // (layers + 3))
        layer_width = int((width * 0.7) * (1 - layer / float(layers + 1.5)))
        layer_height = random.randint(12, 18)

        for dy in range(layer_height):
            progress = dy / float(layer_height)
            half_w = int(layer_width * (1 - progress * 0.85) / 2)
            for dx in range(-half_w, half_w + 1):
                px = cx + dx
                py = layer_y + dy
                if 0 <= px < width and 0 <= py < height:
                    t = progress
                    if t < 0.25:
                        c = leaf_colors[3]
                    elif t < 0.5:
                        c = leaf_colors[2]
                    elif t < 0.75:
                        c = leaf_colors[1]
                    else:
                        c = leaf_colors[0]
                    if random.random() < 0.1:
                        c = darker(c, 20)
                    draw.point((px, py), fill=c)

    return img


def generate_dead_tree(width=TREE_WIDTH, height=TREE_HEIGHT, variant=0):
    img = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    trunk_colors = [
        (60, 50, 40, 255),
        (80, 65, 50, 255),
        (95, 78, 60, 255),
    ]

    cx = width // 2
    trunk_width = random.randint(5, 8)
    trunk_height = int(height * 0.7)
    trunk_bottom = height - 2
    trunk_top = trunk_bottom - trunk_height

    for y in range(trunk_top, trunk_bottom + 1):
        tw = max(3, trunk_width - (y - trunk_top) // 15)
        for x in range(cx - tw // 2, cx + tw // 2 + 1):
            c = trunk_colors[random.randint(0, 2)]
            draw.point((x, y), fill=c)

    for _ in range(random.randint(4, 7)):
        start_y = random.randint(trunk_top + 5, trunk_bottom - 15)
        direction = random.choice([-1, 1])
        length = random.randint(8, 16)
        x, y = cx + direction * (trunk_width // 2), start_y
        for i in range(length):
            x += direction
            y -= random.randint(0, 1)
            if 0 <= x < width and 0 <= y < height:
                draw.point((x, y), fill=trunk_colors[1])
                if random.random() < 0.3:
                    draw.point((x, y + 1), fill=darker(trunk_colors[0]))

    return img


def pack_atlas(trees, atlas_size=ATLAS_SIZE):
    """Simple shelf packer - بدون type hint برای سازگاری بیشتر"""
    atlas = Image.new("RGBA", (atlas_size, atlas_size), (0, 0, 0, 0))
    meta = []

    x = 2
    y = 2
    row_height = 0

    for idx, tree in enumerate(trees):
        w, h = tree.size
        if x + w + 2 > atlas_size:
            x = 2
            y += row_height + 2
            row_height = 0

        if y + h + 2 > atlas_size:
            print("Warning: Atlas full, only packed {} trees".format(idx))
            break

        atlas.paste(tree, (x, y), tree)
        meta.append({
            "id": idx,
            "name": "tree_{}".format(idx),
            "x": x,
            "y": y,
            "w": w,
            "h": h
        })

        x += w + 2
        row_height = max(row_height, h)

    return atlas, meta


def main():
    OUTPUT_DIR.mkdir(exist_ok=True)
    (OUTPUT_DIR / "individual").mkdir(exist_ok=True)

    print("Generating {} tree variants ({}x{})...".format(NUM_VARIANTS, TREE_WIDTH, TREE_HEIGHT))

    trees = []
    for i in range(NUM_VARIANTS):
        if i < 4:
            tree = generate_oak_tree(variant=i)
            name = "oak_{}".format(i)
        elif i < 6:
            tree = generate_pine_tree(variant=i)
            name = "pine_{}".format(i - 4)
        else:
            tree = generate_dead_tree(variant=i)
            name = "dead_{}".format(i - 6)

        trees.append(tree)
        tree.save(OUTPUT_DIR / "individual" / "{}.png".format(name))
        print("  saved individual/{}.png".format(name))

    print("\nPacking atlas...")
    atlas, meta = pack_atlas(trees)

    atlas_path = OUTPUT_DIR / "trees_atlas.png"
    atlas.save(atlas_path)
    print("  Atlas saved → {}".format(atlas_path))

    meta_data = {
        "atlas": "trees_atlas.png",
        "tile_width": TREE_WIDTH,
        "tile_height": TREE_HEIGHT,
        "trees": meta
    }
    json_path = OUTPUT_DIR / "trees_atlas.json"
    with open(str(json_path), "w", encoding="utf-8") as f:
        json.dump(meta_data, f, indent=2)
    print("  Metadata saved → {}".format(json_path))

    print("\nDone!")
    print("Output folder: {}".format(OUTPUT_DIR.resolve()))


if __name__ == "__main__":
    main()