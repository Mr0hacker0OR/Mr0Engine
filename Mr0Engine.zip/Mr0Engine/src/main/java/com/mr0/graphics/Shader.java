
package mr0.graphics;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.joml.Matrix4f;
import org.lwjgl.system.MemoryStack;

import static org.lwjgl.opengl.GL20.*;

public class Shader {

    private final int program;
    public void setFloat(String name, float value) {
        glUniform1f(glGetUniformLocation(program, name), value);
    }
    public Shader(String vertexPath, String fragmentPath)
            throws IOException {

        String vertexSource =
                Files.readString(Path.of(vertexPath));

        String fragmentSource =
                Files.readString(Path.of(fragmentPath));

        int vertex = compile(
                GL_VERTEX_SHADER,
                vertexSource
        );

        int fragment = compile(
                GL_FRAGMENT_SHADER,
                fragmentSource
        );

        program = glCreateProgram();

        glAttachShader(program, vertex);
        glAttachShader(program, fragment);

        glLinkProgram(program);

        if (glGetProgrami(program, GL_LINK_STATUS) == 0) {
            throw new RuntimeException(
                    glGetProgramInfoLog(program)
            );
        }

        glDeleteShader(vertex);
        glDeleteShader(fragment);
    }
    public void setVec4(String name, float x, float y, float z, float w) {
        glUniform4f(glGetUniformLocation(program, name), x, y, z, w);
    }
    private int compile(int type, String source) {

        int shader = glCreateShader(type);

        glShaderSource(shader, source);
        glCompileShader(shader);

        if (glGetShaderi(shader, GL_COMPILE_STATUS) == 0) {
            throw new RuntimeException(
                    glGetShaderInfoLog(shader)
            );
        }

        return shader;
    }

    public void use() {
        glUseProgram(program);
    }

    public void setInt(String name, int value) {
        glUniform1i(
                glGetUniformLocation(program, name),
                value
        );
    }

    public void setMatrix(String name, Matrix4f matrix) {
        try (org.lwjgl.system.MemoryStack stack = org.lwjgl.system.MemoryStack.stackPush()) {
            glUniformMatrix4fv(
                    glGetUniformLocation(program, name),
                    false,
                    matrix.get(stack.mallocFloat(16))
            );
        }
    }

    public void setVec2(String name, float x, float y) {
        glUniform2f(glGetUniformLocation(program, name), x, y);
    }
    public void destroy() {
        glDeleteProgram(program);
    }
}