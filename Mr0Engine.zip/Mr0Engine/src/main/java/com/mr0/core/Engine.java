package mr0.core;

import mr0.entity.Player;
import mr0.graphics.*;
import mr0.world.*;

import org.joml.Matrix4f;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

public class Engine {

    private final int width = 1280;
    private final int height = 720;

    private Window window;
    private Renderer renderer;
    private CharacterRenderer charRenderer;
    private HighlightRenderer highlightRenderer;
    private TextRenderer textRenderer;
    private Camera camera;

    private World world;
    private WorldGenerator generator;
    private ChunkLoader chunkLoader;
    private Player player;

    private Framebuffer fbo;
    private PostProcessRenderer postRenderer;
    private int shaderMode = 0;

    private enum GameState { CUSTOMIZATION, PLAYING, SETTINGS }
    private GameState currentState = GameState.CUSTOMIZATION;
    private Biome lastBiome = null;

    private long currentSeed = 12345L;
    private float timeOfDay = 0.0f;
    private final float daySpeed = 0.01f;

    private Raycast.Hit currentHit;
    private final float REACH_TILES = 6f;
    private double lastTime;

    private int menuCategory = 0;
    private final String[] catNames = {"Base", "Hair", "Hat", "Shirt", "Pants", "Boots", "Accessory"};
    private int settingOption = 0;
    private final String[] shaderNames = {"OFF", "CRT (Old TV)", "COLOR (Vivid)"};

    public void start() throws Exception {
        BlockRegistry.load("assets/config/blocks.json");

        window = new Window(width, height, "Mr0 2D Engine");
        Input input = window.getInput();

        Shader shader = new Shader("src/main/resources/shaders/basic.vert", "src/main/resources/shaders/basic.frag");
        Shader solidShader = new Shader("src/main/resources/shaders/solid.vert", "src/main/resources/shaders/solid.frag");
        Shader bgShader = new Shader("src/main/resources/shaders/background.vert", "src/main/resources/shaders/background.frag");
        Shader postShader = new Shader("src/main/resources/shaders/post.vert", "src/main/resources/shaders/post.frag");
        Shader textShader = new Shader("src/main/resources/shaders/text.vert", "src/main/resources/shaders/text.frag");

        Texture worldTexture = new Texture("assets/textures/atlas.png");
        TreeRenderer treeRenderer = new TreeRenderer("assets/textures/trees/trees_atlas.png", "assets/textures/trees/trees_atlas.json");

        renderer = new Renderer(shader, worldTexture, treeRenderer);
        renderer.initBackground(bgShader);

        charRenderer = new CharacterRenderer(shader);
        highlightRenderer = new HighlightRenderer(solidShader);

        try {
            textRenderer = new TextRenderer(textShader, "assets/fonts/font.ttf", 24);
        } catch (Exception e) {
            System.err.println("⚠️ فونت پیدا نشد!");
            e.printStackTrace();
        }

        fbo = new Framebuffer(width, height);
        postRenderer = new PostProcessRenderer(postShader, width, height);

        camera = new Camera();
        camera.setZoom(1.0f);

        setupWorld(currentSeed);

        player = new Player(0, 0, null);
        player.width = 64f;
        player.height = 64f;

        glDisable(GL_DEPTH_TEST);

        lastTime = glfwGetTime();
        loop();
        cleanup();
    }

    private void setupWorld(long seed) {
        world = new World();
        generator = new WorldGenerator(seed, world);
        world.setWorldGenerator(generator);
        chunkLoader = new ChunkLoader(world, generator, 2);
        lastBiome = null;
    }

    private void loop() {
        Input input = window.getInput();

        while (!window.shouldClose()) {
            double now = glfwGetTime();
            float delta = (float) (now - lastTime);
            if (delta > 0.1f) delta = 0.1f;
            lastTime = now;

            input.poll();

            // 🌟 گرفتن سایز فعلی پنجره (برای فول‌اسکرین و ریسایز)
            int currentWidth = window.getWidth();
            int currentHeight = window.getHeight();

            // اگه سایز صفر شد (موقع مینیمایز)، فریم رو رندر نکن
            if (currentWidth == 0 || currentHeight == 0) {
                input.endFrame();
                window.update();
                continue;
            }

            fbo.bind();
            // 🌟 تنظیم ویوپورت با سایز جدید
            glViewport(0, 0, currentWidth, currentHeight);
            glClearColor(0f, 0f, 0f, 1f);
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

            if (currentState == GameState.CUSTOMIZATION) {
                updateCustomization(input);
                renderCustomization(currentWidth, currentHeight);
            } else if (currentState == GameState.PLAYING) {
                updateGame(delta, input, currentWidth, currentHeight);
                renderGame(currentWidth, currentHeight);
            } else if (currentState == GameState.SETTINGS) {
                updateSettings(input);
                renderSettings(currentWidth, currentHeight);
            }

            fbo.unbind();
            // 🌟 تنظیم مجدد ویوپورت برای صفحه اصلی
            glViewport(0, 0, currentWidth, currentHeight);
            fbo.resize(currentWidth, currentHeight);
            postRenderer.render(fbo.getTexture(), shaderMode, timeOfDay);

            input.endFrame();
            window.update();
        }
    }
    // --- منوی شخصی‌سازی ---
    private void updateCustomization(Input input) {
        if (input.isKeyPressed(GLFW_KEY_DOWN)) menuCategory = (menuCategory + 1) % 7;
        if (input.isKeyPressed(GLFW_KEY_UP)) menuCategory = (menuCategory - 1 + 7) % 7;

        int dir = 0;
        if (input.isKeyPressed(GLFW_KEY_RIGHT)) dir = 1;
        if (input.isKeyPressed(GLFW_KEY_LEFT)) dir = -1;

        if (dir != 0) {
            switch (menuCategory) {
                case 0: player.appearance.baseId = Math.max(0, player.appearance.baseId + dir); break;
                case 1: player.appearance.hairId = Math.max(0, player.appearance.hairId + dir); break;
                case 2: player.appearance.hatId = Math.max(-1, player.appearance.hatId + dir); break;
                case 3: player.appearance.shirtId = Math.max(0, player.appearance.shirtId + dir); break;
                case 4: player.appearance.pantsId = Math.max(0, player.appearance.pantsId + dir); break;
                case 5: player.appearance.bootsId = Math.max(0, player.appearance.bootsId + dir); break;
                case 6: player.appearance.accId = Math.max(-1, player.appearance.accId + dir); break;
            }
        }

        if (input.isKeyPressed(GLFW_KEY_ENTER)) {
            currentState = GameState.PLAYING;
            int surfaceTileY = generator.surfaceYAt(0);
            player.x = 0f;
            player.y = (surfaceTileY + 2) * Chunk.TILE_SIZE;
            chunkLoader.update(player.centerX(), player.centerY());
            camera.setImmediate(player.centerX(), player.centerY());
        }
    }

    private void renderCustomization(int currentWidth, int currentHeight) {
        glClearColor(0.15f, 0.15f, 0.2f, 1f);
        glClear(GL_COLOR_BUFFER_BIT);

        Matrix4f menuProj = new Matrix4f().ortho(
                -currentWidth / 2f, currentWidth / 2f,
                -currentHeight / 2f, currentHeight / 2f,
                -1f, 1f
        );
        charRenderer.render(player, 0, 0, menuProj);
    }

    // --- بخش بازی ---
    private void updateGame(float delta, Input input, int currentWidth, int currentHeight) {
        if (input.isKeyPressed(GLFW_KEY_ESCAPE)) {
            currentState = GameState.SETTINGS;
            return;
        }

        boolean left  = input.isKeyDown(GLFW_KEY_A) || input.isKeyDown(GLFW_KEY_LEFT);
        boolean right = input.isKeyDown(GLFW_KEY_D) || input.isKeyDown(GLFW_KEY_RIGHT);
        boolean jump  = input.isKeyDown(GLFW_KEY_SPACE);

        // 🌟 تشخیص جهت حرکت و پاس دادن به رندرر
        player.update(world, delta, left, right, jump);
        // 🌟 تنظیم جهت نگاه کاراکتر بر اساس حرکت

        world.updateItems(delta, player);
// به جای updateAim(input); این رو بذار:
        updateAim(input, currentWidth, currentHeight);

        double scroll = input.getScrollY();
        if (scroll > 0) player.inventory.selectedSlot = (player.inventory.selectedSlot - 1 + 9) % 9;
        else if (scroll < 0) player.inventory.selectedSlot = (player.inventory.selectedSlot + 1) % 9;

        // 🌟 کندن بلاک با کلیک چپ
        if (input.isLeftPressed() && currentHit != null) {
            short blockId = world.getBlockAtTile(currentHit.tileX, currentHit.tileY);
            if (blockId != 0) {
                world.setBlockAtTile(currentHit.tileX, currentHit.tileY, (short) 0);
                float dropX = (currentHit.tileX + 0.5f) * Chunk.TILE_SIZE;
                float dropY = (currentHit.tileY + 0.5f) * Chunk.TILE_SIZE;
                world.addItemDrop(new ItemDrop(dropX, dropY, blockId));
            }
        }

        // 🌟 گذاشتن بلاک با کلیک راست
        if (input.isRightPressed() && currentHit != null) {
            if (player.inventory.getCurrentBlock() != 0) {
                placeBlock();
            }
        }

        chunkLoader.update(player.centerX(), player.centerY());
        camera.follow(player.centerX(), player.centerY(), delta);

        Biome currentBiome = world.getBiomeAtPixel(player.centerX(), player.centerY());
        if (currentBiome != lastBiome) {
            lastBiome = currentBiome;
            renderer.setBiome(currentBiome.getName(), currentBiome.getBackgroundPath());
        }

        timeOfDay += daySpeed * delta;
        if (timeOfDay > 1.0f) timeOfDay = 0.0f;
    }

    private void renderGame(int currentWidth, int currentHeight) {
        renderer.beginFrame(currentWidth, currentHeight);
        renderer.renderWorld(world, camera, currentWidth, currentHeight);

        Matrix4f proj = camera.getProjection(currentWidth, currentHeight);

        if (currentHit != null) {
            highlightRenderer.render(
                    currentHit.tileX * Chunk.TILE_SIZE,
                    currentHit.tileY * Chunk.TILE_SIZE,
                    Chunk.TILE_SIZE,
                    proj
            );
        }

        charRenderer.render(player, player.centerX(), player.centerY(), proj);
        renderer.renderItems(world, camera, currentWidth, currentHeight);

        // 🌟 نوار اینونتوری هم باید با سایز جدید هماهنگ بشه
        renderHotbar(currentWidth, currentHeight);
    }
    private void renderHotbar(int currentWidth, int currentHeight) {
        if (textRenderer == null) return;

        Matrix4f uiProj = new Matrix4f().ortho(0, currentWidth, currentHeight, 0, -1, 1);

        float startX = currentWidth / 2f - 180; // وسط صفحه
        float y = currentHeight - 50;           // پایین صفحه

        for (int i = 0; i < 9; i++) {
            String slotText;
            float r, g, b;
            if (player.inventory.getSlot(i) == 0) {
                slotText = "[  ]";
                r = g = b = 0.4f;
            } else {
                slotText = "[" + player.inventory.getCount(i) + "]";
                r = g = b = 1f;
            }

            if (i == player.inventory.selectedSlot) {
                r = 1f; g = 0.8f; b = 0.2f;
            }

            textRenderer.drawText(slotText, startX + i * 40, y, 1.0f, uiProj, r, g, b, 1f);
        }
    }

    private void updateSettings(Input input) {
        if (input.isKeyPressed(GLFW_KEY_ESCAPE)) {
            currentState = GameState.PLAYING;
            return;
        }

        if (input.isKeyPressed(GLFW_KEY_DOWN)) settingOption = (settingOption + 1) % 2;
        if (input.isKeyPressed(GLFW_KEY_UP)) settingOption = (settingOption - 1 + 2) % 2;

        int dir = 0;
        if (input.isKeyPressed(GLFW_KEY_RIGHT)) dir = 1;
        if (input.isKeyPressed(GLFW_KEY_LEFT)) dir = -1;

        if (dir != 0) {
            if (settingOption == 0) {
                shaderMode = (shaderMode + dir + 3) % 3;
            } else if (settingOption == 1) {
                currentSeed += dir;
                setupWorld(currentSeed);
                int surfaceTileY = generator.surfaceYAt(0);
                player.x = 0f;
                player.y = (surfaceTileY + 2) * Chunk.TILE_SIZE;
                chunkLoader.update(player.centerX(), player.centerY());
                camera.setImmediate(player.centerX(), player.centerY());
            }
        }
    }

    private void renderSettings(int currentWidth, int currentHeight) {
        glClearColor(0.1f, 0.1f, 0.15f, 1f);
        glClear(GL_COLOR_BUFFER_BIT);

        if (textRenderer == null) return;

        Matrix4f uiProj = new Matrix4f().ortho(0, currentWidth, currentHeight, 0, -1, 1);

        // محاسبه مرکز صفحه برای متن SETTINGS
        float titleX = currentWidth / 2f - 60;

        textRenderer.drawText("SETTINGS", titleX, 100, 1.5f, uiProj, 1f, 1f, 1f, 1f);

        float shaderColor = (settingOption == 0) ? 1f : 0.5f;
        textRenderer.drawText((settingOption == 0 ? "> " : "  ") + "Shader: " + shaderNames[shaderMode], 200, 200, 1.2f, uiProj, shaderColor, shaderColor, 0.3f, 1f);

        float seedColor = (settingOption == 1) ? 1f : 0.5f;
        textRenderer.drawText((settingOption == 1 ? "> " : "  ") + "Seed: " + currentSeed, 200, 250, 1.2f, uiProj, seedColor, seedColor, 0.3f, 1f);

        textRenderer.drawText("UP/DOWN to select, LEFT/RIGHT to change", 200, 400, 0.8f, uiProj, 0.7f, 0.7f, 0.7f, 1f);
        textRenderer.drawText("Press ESC to return to game", 200, 430, 0.8f, uiProj, 0.7f, 0.7f, 0.7f, 1f);
    }

    private void updateAim(Input input, int currentWidth, int currentHeight) {
        float mx = (float) input.getMouseX();
        float my = (float) input.getMouseY();
        float zoom = camera.getZoom();

        // 🌟 استفاده از سایز داینامیک صفحه
        float halfW = currentWidth / (2f * zoom);
        float halfH = currentHeight / (2f * zoom);

        float worldX = camera.getX() - halfW + (mx / currentWidth) * (2f * halfW);
        float worldY = camera.getY() + halfH - (my / currentHeight) * (2f * halfH);

        float pcx = player.centerX();
        float pcy = player.centerY();
        currentHit = Raycast.cast(world, pcx, pcy, worldX - pcx, worldY - pcy, Chunk.TILE_SIZE, (int) REACH_TILES);
    }
    private void placeBlock() {
        if (currentHit == null) return;

        float pcx = player.centerX();
        float pcy = player.centerY();

        float tileCenterX = (currentHit.tileX + 0.5f) * Chunk.TILE_SIZE;
        float tileCenterY = (currentHit.tileY + 0.5f) * Chunk.TILE_SIZE;

        float dx = tileCenterX - pcx;
        float dy = tileCenterY - pcy;

        int placeX = currentHit.tileX;
        int placeY = currentHit.tileY;

        if (Math.abs(dx) > Math.abs(dy)) {
            placeX += dx > 0 ? -1 : 1;
        } else {
            placeY += dy > 0 ? -1 : 1;
        }

        if (world.getBlockAtTile(placeX, placeY) != 0) return;

        float pLeft   = player.x;
        float pRight  = player.x + player.width;
        float pBottom = player.y;
        float pTop    = player.y + player.height;

        float bLeft   = placeX * Chunk.TILE_SIZE;
        float bRight  = bLeft + Chunk.TILE_SIZE;
        float bBottom = placeY * Chunk.TILE_SIZE;
        float bTop    = bBottom + Chunk.TILE_SIZE;

        boolean overlap = !(pRight <= bLeft || pLeft >= bRight ||
                pTop <= bBottom || pBottom >= bTop);

        if (overlap) return;

        short blockToPlace = player.inventory.getCurrentBlock();
        if (blockToPlace == 0) return;

        if (player.inventory.removeBlock()) {
            world.setBlockAtTile(placeX, placeY, blockToPlace);
            if (world.getWallAtTile(placeX, placeY) == 0) {
                world.setWallAtTile(placeX, placeY, blockToPlace);
            }
        }
    }

    private void cleanup() {
        renderer.destroy();
        charRenderer.destroy();
        highlightRenderer.destroy();
        fbo.destroy();
        window.destroy();
    }
}