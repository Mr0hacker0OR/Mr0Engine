package mr0.graphics;

import mr0.entity.Entity;
import mr0.entity.Player;

import org.joml.Matrix4f;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

import org.lwjgl.BufferUtils;

public class SpriteRenderer {

    private final int vao;
    private final int vbo;
    private final int ebo;

    private final Shader shader;
    private final Texture texture;

    private final float[] vertices = new float[16];
    private final int[] indices = {
            0, 1, 2,
            2, 3, 0
    };

    public SpriteRenderer(Shader shader, Texture texture) {

        this.shader = shader;
        this.texture = texture;

        vao = glGenVertexArrays();
        vbo = glGenBuffers();
        ebo = glGenBuffers();

        glBindVertexArray(vao);

        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, (long) vertices.length * Float.BYTES,
                GL_DYNAMIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
        IntBuffer ib = BufferUtils.createIntBuffer(indices.length);
        ib.put(indices).flip();
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, ib, GL_STATIC_DRAW);

        int stride = 4 * Float.BYTES;
        glVertexAttribPointer(0, 2, GL_FLOAT, false, stride, 0);
        glEnableVertexAttribArray(0);

        glVertexAttribPointer(1, 2, GL_FLOAT, false, stride, 2L * Float.BYTES);
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);
    }

    public void render(Player player, Matrix4f projection) {

        shader.use();
        shader.setMatrix("uProjection", projection);

        glActiveTexture(GL_TEXTURE0);
        texture.bind();
        shader.setInt("uTexture", 0);

        // ⭐️ فعال کردن شفافیت (Blending) ⭐️
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        float[] uv = player.animation.getUV();

        float x0 = player.x;
        float y0 = player.y;
        float x1 = player.x + player.width;
        float y1 = player.y + player.height;

        vertices[0] = x0; vertices[1] = y0; vertices[2] = uv[0]; vertices[3] = uv[1];
        vertices[4] = x1; vertices[5] = y0; vertices[6] = uv[2]; vertices[7] = uv[1];
        vertices[8] = x1; vertices[9] = y1; vertices[10] = uv[2]; vertices[11] = uv[3];
        vertices[12] = x0; vertices[13] = y1; vertices[14] = uv[0]; vertices[15] = uv[3];

        FloatBuffer fb = BufferUtils.createFloatBuffer(vertices.length);
        fb.put(vertices).flip();

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferSubData(GL_ARRAY_BUFFER, 0, fb);

        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);

        // ⭐️ خاموش کردن شفافیت ⭐️
        glDisable(GL_BLEND);
    }

    public void destroy() {
        glDeleteBuffers(vbo);
        glDeleteBuffers(ebo);
        glDeleteVertexArrays(vao);
        texture.destroy();
    }
}