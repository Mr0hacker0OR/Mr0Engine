package mr0.world;

import mr0.entity.Player;
import java.util.*;

public class World {
    private final Map<Long, Chunk> chunks = new HashMap<>();
    private final List<Tree> trees = new ArrayList<>();
    private final List<FallingTreePart> fallingParts = new ArrayList<>();
    private final List<ItemDrop> itemDrops = new ArrayList<>();
    private final List<String> structures = new ArrayList<>();
    private WorldGenerator worldGenerator;

    private long key(int x, int y) {
        return ((long) x << 32) | (y & 0xffffffffL);
    }

    // ---------- CHUNK MANAGEMENT ----------
    public void addChunk(Chunk chunk) {
        chunks.put(key(chunk.getChunkX(), chunk.getChunkY()), chunk);
    }
    public void removeChunk(Chunk chunk) {
        chunks.remove(key(chunk.getChunkX(), chunk.getChunkY()));
    }
    public Chunk getChunk(int x, int y) {
        return chunks.get(key(x, y));
    }
    public Collection<Chunk> getChunks() { return chunks.values(); }
    public int getChunkCount() { return chunks.size(); }

    // ---------- BLOCK ACCESS ----------
    public short getBlockAtTile(int tileX, int tileY) {
        int cx = Math.floorDiv(tileX, Chunk.SIZE);
        int cy = Math.floorDiv(tileY, Chunk.SIZE);
        int lx = Math.floorMod(tileX, Chunk.SIZE);
        int ly = Math.floorMod(tileY, Chunk.SIZE);
        Chunk c = getChunk(cx, cy);
        return c == null ? 0 : c.getBlock(lx, ly);
    }

    public void setBlockAtTile(int tileX, int tileY, short id) {
        int cx = Math.floorDiv(tileX, Chunk.SIZE);
        int cy = Math.floorDiv(tileY, Chunk.SIZE);
        int lx = Math.floorMod(tileX, Chunk.SIZE);
        int ly = Math.floorMod(tileY, Chunk.SIZE);
        Chunk c = getChunk(cx, cy);
        if (c == null) return;
        c.setBlock(lx, ly, id);

        if (lx == 0) markDirty(cx - 1, cy);
        if (lx == Chunk.SIZE - 1) markDirty(cx + 1, cy);
        if (ly == 0) markDirty(cx, cy - 1);
        if (ly == Chunk.SIZE - 1) markDirty(cx, cy + 1);
    }

    public boolean isSolidTile(int tileX, int tileY) {
        Block b = BlockRegistry.get(getBlockAtTile(tileX, tileY));
        return b != null && b.solid;
    }

    public short getWallAtTile(int tileX, int tileY) {
        int cx = Math.floorDiv(tileX, Chunk.SIZE);
        int cy = Math.floorDiv(tileY, Chunk.SIZE);
        int lx = Math.floorMod(tileX, Chunk.SIZE);
        int ly = Math.floorMod(tileY, Chunk.SIZE);
        Chunk c = getChunk(cx, cy);
        return c == null ? 0 : c.getWall(lx, ly);
    }

    public void setWallAtTile(int tileX, int tileY, short id) {
        int cx = Math.floorDiv(tileX, Chunk.SIZE);
        int cy = Math.floorDiv(tileY, Chunk.SIZE);
        int lx = Math.floorMod(tileX, Chunk.SIZE);
        int ly = Math.floorMod(tileY, Chunk.SIZE);
        Chunk c = getChunk(cx, cy);
        if (c == null) return;
        c.setWall(lx, ly, id);
        if (lx == 0) markWallsDirty(cx - 1, cy);
        if (lx == Chunk.SIZE - 1) markWallsDirty(cx + 1, cy);
        if (ly == 0) markWallsDirty(cx, cy - 1);
        if (ly == Chunk.SIZE - 1) markWallsDirty(cx, cy + 1);
    }

    private void markDirty(int x, int y) {
        Chunk c = getChunk(x, y);
        if (c != null) c.markDirty();
    }
    private void markWallsDirty(int x, int y) {
        Chunk c = getChunk(x, y);
        if (c != null) c.markWallsDirty();
    }

    public static int tileSize() { return Chunk.TILE_SIZE; }

    // ---------- BIOME ----------
    public void setWorldGenerator(WorldGenerator gen) { this.worldGenerator = gen; }
    public Biome getBiomeAtTile(int tileX, int tileY) {
        if (worldGenerator == null) return Biome.PLAINS;
        return worldGenerator.getBiomeAt(tileX, tileY);
    }
    public Biome getBiomeAtPixel(float pixelX, float pixelY) {
        int tx = (int) Math.floor(pixelX / Chunk.TILE_SIZE);
        int ty = (int) Math.floor(pixelY / Chunk.TILE_SIZE);
        return getBiomeAtTile(tx, ty);
    }

    // ---------- ITEMS ----------
    public void addItemDrop(ItemDrop drop) { itemDrops.add(drop); }
    public List<ItemDrop> getItemDrops() { return itemDrops; }
    public void updateItems(float dt, Player player) {
        for (int i = itemDrops.size() - 1; i >= 0; i--) {
            ItemDrop drop = itemDrops.get(i);
            drop.update(dt, player, this);
            if (drop.collected) {
                player.inventory.addBlock(drop.blockId);
                itemDrops.remove(i);
            }
        }
    }

    // ---------- TREES ----------
    public void addTree(Tree tree) { trees.add(tree); }
    public List<Tree> getTrees() { return trees; }
    public List<FallingTreePart> getFallingParts() { return fallingParts; }
    public void addFallingPart(FallingTreePart part) { fallingParts.add(part); }

    public boolean hasTreeNear(int wx, int wy, int radius) {
        for (Tree t : trees) {
            if (Math.abs(t.baseX - wx) <= radius && Math.abs(t.baseY - wy) <= radius) return true;
        }
        return false;
    }

    public Tree getTreeAtPixel(int pixelX, int pixelY) {
        for (Tree t : trees) {
            if (!t.removed && t.contains(pixelX, pixelY)) return t;
        }
        return null;
    }

    public void updateTrees(float dt) {
        for (int i = fallingParts.size() - 1; i >= 0; i--) {
            FallingTreePart p = fallingParts.get(i);
            p.update(dt);
            if (p.dead) fallingParts.remove(i);
        }
    }

    // ---------- STRUCTURES ----------
    public void addStructure(String type, int x, int y) {
        structures.add(type + "@" + x + "," + y);
    }

    public boolean hasStructureNear(int x, int y, int radius) {
        for (String s : structures) {
            String[] parts = s.split("@")[1].split(",");
            int sx = Integer.parseInt(parts[0]);
            int sy = Integer.parseInt(parts[1]);
            if (Math.abs(sx - x) <= radius && Math.abs(sy - y) <= radius) return true;
        }
        return false;
    }
}