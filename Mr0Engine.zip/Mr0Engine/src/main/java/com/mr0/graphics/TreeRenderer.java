
package mr0.graphics;

import mr0.world.Tree;
import mr0.world.World;

import org.lwjgl.BufferUtils;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.io.IOException;
import java.util.EnumMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

public class TreeRenderer {

    private static class Sprite {
        int x, y, w, h;

        Sprite(int x, int y, int w, int h) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
        }
    }

    private final Texture texture;

    private final int vao;
    private final int vbo;
    private final int ebo;

    private final Map<Tree.Type, Sprite> sprites =
            new EnumMap<>(Tree.Type.class);

    private int atlasWidth;
    private int atlasHeight;

    private static final int MAX_TREES = 2048;

    // اندازه درخت‌ها نسبت به تصویر اصلی
    private static final float TREE_SCALE = 2.0f;

    public TreeRenderer(String atlasPath, String jsonPath) {

        texture = new Texture(atlasPath);

        atlasWidth = texture.getWidth();
        atlasHeight = texture.getHeight();

        loadAtlasJson(jsonPath);

        vao = glGenVertexArrays();
        vbo = glGenBuffers();
        ebo = glGenBuffers();

        glBindVertexArray(vao);

        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);

        int stride = 4 * Float.BYTES;

        glVertexAttribPointer(
                0, 2, GL_FLOAT, false, stride, 0
        );

        glEnableVertexAttribArray(0);

        glVertexAttribPointer(
                1, 2, GL_FLOAT, false, stride,
                2L * Float.BYTES
        );

        glEnableVertexAttribArray(1);

        glBindVertexArray(0);

        System.out.println(
                "TreeRenderer initialized | Sprites: "
                        + sprites.size()
        );
    }

    // -----------------------------------------
    // LOAD JSON
    // -----------------------------------------

    private void loadAtlasJson(String jsonPath) {

        String json;

        try {
            json = Files.readString(Path.of(jsonPath));
        } catch (IOException e) {
            throw new RuntimeException(
                    "Cannot load tree atlas JSON: " + jsonPath, e
            );
        }

        Pattern pattern = Pattern.compile(
                "\\{\\s*\"id\"\\s*:\\s*(\\d+)" +
                        "\\s*,\\s*\"name\"\\s*:\\s*\"[^\"]+\"" +
                        "\\s*,\\s*\"x\"\\s*:\\s*(\\d+)" +
                        "\\s*,\\s*\"y\"\\s*:\\s*(\\d+)" +
                        "\\s*,\\s*\"w\"\\s*:\\s*(\\d+)" +
                        "\\s*,\\s*\"h\"\\s*:\\s*(\\d+)" +
                        "\\s*\\}"
        );

        Matcher matcher = pattern.matcher(json);

        int loaded = 0;

        while (matcher.find()) {

            int id = Integer.parseInt(matcher.group(1));
            int x = Integer.parseInt(matcher.group(2));
            int y = Integer.parseInt(matcher.group(3));
            int w = Integer.parseInt(matcher.group(4));
            int h = Integer.parseInt(matcher.group(5));

            if (x < 0 || y < 0 || w <= 0 || h <= 0 ||
                    x + w > atlasWidth || y + h > atlasHeight) {

                throw new IllegalArgumentException(
                        "Invalid tree sprite bounds: ID " + id
                );
            }

            Tree.Type type = typeFromId(id);

            if (type != null) {
                sprites.put(type, new Sprite(x, y, w, h));
                loaded++;
            }
        }

        if (loaded == 0) {
            throw new RuntimeException(
                    "No tree sprites found in JSON: " + jsonPath
            );
        }
    }

    private Tree.Type typeFromId(int id) {

        switch (id) {
            case 0: return Tree.Type.OAK_0;
            case 1: return Tree.Type.OAK_1;
            case 2: return Tree.Type.OAK_2;
            case 3: return Tree.Type.OAK_3;

            case 4: return Tree.Type.PINE_0;
            case 5: return Tree.Type.PINE_1;

            case 6: return Tree.Type.DEAD_0;
            case 7: return Tree.Type.DEAD_1;

            default: return null;
        }
    }

    // -----------------------------------------
    // RENDER TREES
    // -----------------------------------------

    public void render(World world) {

        if (world.getTrees().isEmpty()) return;

        float[] vertices = new float[MAX_TREES * 16];
        int[] indices = new int[MAX_TREES * 6];

        int vo = 0;
        int io = 0;
        int vertexBase = 0;

        for (Tree tree : world.getTrees()) {

            if (tree.removed || tree.currentHeight <= 0) {
                continue;
            }

            Sprite sprite = sprites.get(tree.type);

            if (sprite == null) continue;

            if (io / 6 >= MAX_TREES) break;

            // ارتفاع قسمت قابل نمایش تصویر اصلی
            int sourceHeight = Math.min(
                    tree.currentHeight,
                    sprite.h
            );

            if (sourceHeight <= 0) continue;

            // اندازه نمایشی درخت
            float drawWidth = sprite.w * TREE_SCALE;
            float drawHeight = sourceHeight * TREE_SCALE;

            // مختصات پایه درخت
            float baseX = tree.baseX * World.tileSize();
            float baseY = tree.baseY * World.tileSize();

            // مختصات هندسی
            float px = baseX - drawWidth / 2f;
            float right = px + drawWidth;

            float bottom = baseY;
            float top = baseY + drawHeight;

            // محل برش تصویر در اطلس
            int sourceY = sprite.y + sprite.h - sourceHeight;

            // UV coordinates
            // فرض: تصویر در Texture به صورت عمودی flip شده است.
            float u0 = (float) sprite.x / atlasWidth;
            float u1 = (float) (sprite.x + sprite.w) / atlasWidth;

            float vTop = 1f - (float) sourceY / atlasHeight;
            float vBottom = 1f -
                    (float) (sourceY + sourceHeight) / atlasHeight;

            // Bottom-left
            vertices[vo++] = px;
            vertices[vo++] = bottom;
            vertices[vo++] = u0;
            vertices[vo++] = vBottom;

            // Bottom-right
            vertices[vo++] = right;
            vertices[vo++] = bottom;
            vertices[vo++] = u1;
            vertices[vo++] = vBottom;

            // Top-right
            vertices[vo++] = right;
            vertices[vo++] = top;
            vertices[vo++] = u1;
            vertices[vo++] = vTop;

            // Top-left
            vertices[vo++] = px;
            vertices[vo++] = top;
            vertices[vo++] = u0;
            vertices[vo++] = vTop;

            // Indices - CCW
            indices[io++] = vertexBase;
            indices[io++] = vertexBase + 1;
            indices[io++] = vertexBase + 2;

            indices[io++] = vertexBase + 2;
            indices[io++] = vertexBase + 3;
            indices[io++] = vertexBase;

            vertexBase += 4;
        }

        if (io == 0) return;

        upload(vertices, vo, indices, io);

        boolean blendWasEnabled = glIsEnabled(GL_BLEND);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glActiveTexture(GL_TEXTURE0);
        texture.bind();

        glBindVertexArray(vao);

        glDrawElements(
                GL_TRIANGLES,
                io,
                GL_UNSIGNED_INT,
                0
        );

        glBindVertexArray(0);

        if (!blendWasEnabled) {
            glDisable(GL_BLEND);
        }
    }

    // -----------------------------------------
    // GPU UPLOAD
    // -----------------------------------------

    private void upload(
            float[] vertices,
            int vertexCount,
            int[] indices,
            int indexCount
    ) {

        FloatBuffer vb = BufferUtils.createFloatBuffer(vertexCount);
        vb.put(vertices, 0, vertexCount).flip();

        IntBuffer ib = BufferUtils.createIntBuffer(indexCount);
        ib.put(indices, 0, indexCount).flip();

        glBindVertexArray(vao);

        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, vb, GL_DYNAMIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, ib, GL_DYNAMIC_DRAW);

        glBindVertexArray(0);
    }

    // -----------------------------------------
    // DESTROY
    // -----------------------------------------

    public void destroy() {

        glDeleteBuffers(vbo);
        glDeleteBuffers(ebo);
        glDeleteVertexArrays(vao);

        texture.destroy();

        sprites.clear();
    }
}
