package mr0.world;

import mr0.world.noise.FastNoiseLite;

public class WorldGenerator {

    private final FastNoiseLite terrainNoise;
    private final FastNoiseLite caveNoise;

    private final BiomeMap biomeMap;
    private final TreeGenerator treeGen;
    private final OreGenerator oreGen;
    private final StructureGenerator structureGen;

    private final int surfaceLevel;

    public WorldGenerator(long seed, World world) {
        terrainNoise = new FastNoiseLite((int) seed);
        terrainNoise.SetNoiseType(FastNoiseLite.NoiseType.OpenSimplex2);
        terrainNoise.SetFrequency(0.008f);
        terrainNoise.SetFractalType(FastNoiseLite.FractalType.FBm);
        terrainNoise.SetFractalOctaves(4);

        caveNoise = new FastNoiseLite((int) (seed + 1337));
        caveNoise.SetNoiseType(FastNoiseLite.NoiseType.Perlin);
        caveNoise.SetFrequency(0.03f);

        biomeMap = new BiomeMap(seed + 777);
        treeGen = new TreeGenerator(world);
        oreGen = new OreGenerator(seed + 555);
        structureGen = new StructureGenerator(world, seed + 999);

        surfaceLevel = 20;
    }

    public void generate(Chunk chunk) {
        int chunkWorldX = chunk.getChunkX() * Chunk.SIZE;
        int chunkWorldY = chunk.getChunkY() * Chunk.SIZE;

        // پاس ۱: زمین
        for (int lx = 0; lx < Chunk.SIZE; lx++) {
            for (int ly = 0; ly < Chunk.SIZE; ly++) {
                int wx = chunkWorldX + lx;
                int wy = chunkWorldY + ly;

                Biome biome = biomeMap.getBiome(wx, wy);
                float n = terrainNoise.GetNoise((float) wx, 0f);
                int height = surfaceLevel + (int) (n * 8f);
                if (biome == Biome.SNOW) height += 2;

                short block = 0;
                short wall = 0;

                if (wy <= height) {
                    boolean isCave = false;
                    if (wy < height - 3) {
                        float c = caveNoise.GetNoise((float) wx, (float) wy);
                        if (c > 0.45f) isCave = true;
                    }
                    if (isCave) {
                        block = 0;
                        wall = 3;
                    } else {
                        block = surfaceBlock(biome, wy, height);
                        wall = block;
                    }
                }
                if (block != 0) chunk.setBlock(lx, ly, block);
                if (wall != 0) chunk.setWall(lx, ly, wall);
            }
        }

        // پاس ۲: ذخایر
        oreGen.generate(chunk);

        // پاس ۳: درخت‌ها
        for (int lx = 0; lx < Chunk.SIZE; lx++) {
            int wx = chunkWorldX + lx;
            float n = terrainNoise.GetNoise((float) wx, 0f);
            int height = surfaceLevel + (int) (n * 8f);
            Biome biome = biomeMap.getBiome(wx, height);
            if (biome == Biome.SNOW) height += 2;

            int surfaceLocalY = height - chunkWorldY;
            if (surfaceLocalY >= 0 && surfaceLocalY < Chunk.SIZE) {
                short surfaceBlockId = chunk.getBlock(lx, surfaceLocalY);
                if (surfaceBlockId == 1 || surfaceBlockId == 4 || surfaceBlockId == 6) {
                    treeGen.tryPlaceTree(chunk, wx, height, biome);
                }
            }
        }

        // پاس ۴: سازه‌ها
        for (int lx = 0; lx < Chunk.SIZE; lx++) {
            int wx = chunkWorldX + lx;
            float n = terrainNoise.GetNoise((float) wx, 0f);
            int height = surfaceLevel + (int) (n * 8f);
            Biome biome = biomeMap.getBiome(wx, height);
            if (biome == Biome.SNOW) height += 2;

            int surfaceLocalY = height - chunkWorldY;
            if (surfaceLocalY >= 0 && surfaceLocalY < Chunk.SIZE) {
                structureGen.tryGenerateStructure(chunk, wx, height, biome);
            }
        }

        chunk.markDirty();
        chunk.markWallsDirty();
    }

    private short surfaceBlock(Biome biome, int wy, int height) {
        switch (biome) {
            case SNOW:
                if (wy == height) return 4;
                if (wy >= height - 3) return 5;
                return 3;
            case DESERT:
                if (wy >= height - 3) return 6;
                if (wy >= height - 6) return 7;
                return 3;
            case FOREST:
            case PLAINS:
            default:
                if (wy == height) return 1;
                if (wy >= height - 3) return 2;
                return 3;
        }
    }

    public int getSurfaceLevel() { return surfaceLevel; }

    public int surfaceYAt(int wx) {
        float n = terrainNoise.GetNoise((float) wx, 0f);
        int h = surfaceLevel + (int) (n * 8f);
        Biome b = biomeMap.getBiome(wx, h);
        if (b == Biome.SNOW) h += 2;
        return h;
    }

    public Biome getBiomeAt(int wx, int wy) {
        return biomeMap.getBiome(wx, wy);
    }
}