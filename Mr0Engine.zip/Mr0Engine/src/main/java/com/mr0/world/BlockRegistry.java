package mr0.world;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BlockRegistry {

    public static int TILE_SIZE = 16;
    public static int ATLAS_COLUMNS = 16;
    public static int ATLAS_ROWS = 16;

    private static final Map<Short, Block> BLOCKS = new HashMap<>();
    private static final List<Block> ORDERED = new ArrayList<>();

    public static void load(String path) throws IOException {

        Gson gson = new GsonBuilder().create();

        String json = Files.readString(Path.of(path));

        Config cfg = gson.fromJson(json, Config.class);

        TILE_SIZE = cfg.tileSize;
        ATLAS_COLUMNS = cfg.atlasColumns;
        ATLAS_ROWS = cfg.atlasRows;

        BLOCKS.clear();
        ORDERED.clear();

        for (BlockDef def : cfg.blocks) {

            int top = def.top != null ? def.top : (def.all != null ? def.all : 0);
            int side = def.side != null ? def.side : (def.all != null ? def.all : 0);
            int bottom = def.bottom != null ? def.bottom : (def.all != null ? def.all : 0);

            Block block = new Block(
                    (short) def.id, def.name, def.solid,
                    top, side, bottom
            );

            BLOCKS.put((short) def.id, block);
            ORDERED.add(block);
        }
    }

    public static Block get(short id) {
        Block b = BLOCKS.get(id);
        return b != null ? b : BLOCKS.get((short) 0);
    }

    public static List<Block> all() {
        return ORDERED;
    }

    // --- Gson DTOs ---

    private static class Config {
        int tileSize;
        int atlasColumns;
        int atlasRows;
        List<BlockDef> blocks;
    }

    private static class BlockDef {
        int id;
        String name;
        boolean solid;
        Integer all;
        Integer top;
        Integer side;
        Integer bottom;
    }
}