package mr0.world;

import mr0.world.noise.FastNoiseLite;

public class BiomeMap {

    // ============================================================
    //  ⭐⭐⭐ تنظیم اصلی اندازه بایوم‌ها ⭐⭐⭐
    // ============================================================
    //  عدد کوچیک‌تر → بایوم بزرگ‌تر
    //
    //   0.02f   →  بایوم‌های کوچیک (۳۰-۵۰ تایل، پراکنده)
    //   0.01f   →  بایوم‌های کوچیک (۶۰-۱۰۰ تایل)
    //   0.005f  →  بایوم‌های متوسط (۱۲۰-۲۰۰ تایل)
    //   0.002f  →  بایوم‌های بزرگ (۳۰۰-۵۰۰ تایل)   ← پیشنهاد
    //   0.001f  →  بایوم‌های خیلی بزرگ (۶۰۰-۱۰۰۰ تایل)
    //   0.0005f →  بایوم‌های غول‌پیکر (۱۲۰۰-۲۰۰۰ تایل)
    // ============================================================
    private static final float BIOME_FREQUENCY = 0.002f;

    // ============================================================
    //  ⭐ مرزهای بایوم‌ها (اگه می‌خوای یه بایوم بیشتر جا بگیره، این‌ها رو جابه‌جا کن)
    // ============================================================
    //  خروجی نویز بین -1 تا +1 هست
    //
    //  ▸ اگه می‌خوای SNOW بیشتر بشه → SNOW_MAX رو بزرگ‌تر کن (مثلاً -0.20)
    //  ▸ اگه می‌خوای DESERT بیشتر بشه → FOREST_MAX رو کوچیک‌تر کن (مثلاً 0.30)
    // ============================================================
    private static final float SNOW_MAX   = -0.35f;  // نویز < -0.35  → SNOW
    private static final float PLAINS_MAX =  0.10f;  // -0.35 .. 0.10 → PLAINS
    private static final float FOREST_MAX =  0.45f;  //  0.10 .. 0.45 → FOREST
    //  نویز > 0.45   → DESERT

    private final FastNoiseLite noise;

    public BiomeMap(long seed) {
        noise = new FastNoiseLite((int) seed);
        noise.SetNoiseType(FastNoiseLite.NoiseType.OpenSimplex2);
        noise.SetFrequency(BIOME_FREQUENCY);

        // ⚠️ خیلی مهم: Fractal = None
        // اگه FBm بذاری، لبه بایوم‌ها ناهموار و بایوم‌ها کوچیک‌تر می‌شن
        noise.SetFractalType(FastNoiseLite.FractalType.None);
    }

    /** ورودی: مختصات تایل (نه پیکسل) — خروجی: بایوم */
    public Biome getBiome(int tileX, int tileY) {
        float n = noise.GetNoise(tileX, tileY);  // -1 .. +1

        if (n < SNOW_MAX)   return Biome.SNOW;
        if (n < PLAINS_MAX) return Biome.PLAINS;
        if (n < FOREST_MAX) return Biome.FOREST;
        return Biome.DESERT;
    }
}