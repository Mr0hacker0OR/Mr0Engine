package mr0.world;

import mr0.entity.Player;

public class ItemDrop {
    public float x, y;
    public short blockId;
    public float lifeTime = 0f;
    public boolean collected = false;

    // 🌟 فیلدهای فیزیک
    private float velocityY = 0f;
    private boolean isGrounded = false;
    private final float GRAVITY = -800f; // نیروی جاذبه
    private final float BOUNCE = 0.2f;   // مقدار جهش موقع برخورد

    public ItemDrop(float x, float y, short blockId) {
        this.x = x;
        this.y = y;
        this.blockId = blockId;
        this.velocityY = 150f; // سرعت اولیه به سمت بالا (پرتاب کوچیک موقع کندن)
    }

    public void update(float dt, Player player, World world) { // 🌟 world رو اضافه کردیم
        lifeTime += dt;

        if (!isGrounded) {
            // اعمال جاذبه
            velocityY += GRAVITY * dt;
            y += velocityY * dt;

            // چک کردن برخورد با زمین
            int tileX = (int) (x / Chunk.TILE_SIZE);
            int tileY = (int) (y / Chunk.TILE_SIZE);

            // بلاک پایین آیتم
            short belowBlock = world.getBlockAtTile(tileX, tileY - 1);

            // اگه بلاک پایین جامد بود
            if (belowBlock != 0) {
                float surfaceY = tileY * Chunk.TILE_SIZE;
                if (y <= surfaceY) {
                    y = surfaceY; // آیتم می‌شینه روی بلاک
                    velocityY = -velocityY * BOUNCE; // یکم بالا پایین میشه
                    if (Math.abs(velocityY) < 20f) {
                        velocityY = 0;
                        isGrounded = true; // کاملاً ایستاد
                    }
                }
            }
        }

        // برداشتن آیتم توسط بازیکن
        float distX = Math.abs(x - player.centerX());
        float distY = Math.abs(y - player.centerY());
        if (distX < 32f && distY < 32f) {
            collected = true;
        }
    }
}