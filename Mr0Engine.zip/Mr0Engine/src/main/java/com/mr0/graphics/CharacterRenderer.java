package mr0.graphics;

import mr0.entity.Player;
import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;

import java.nio.FloatBuffer;
import java.util.HashMap;
import java.util.Map;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

public class CharacterRenderer {
    private final Shader shader;
    private final int vao, vbo, ebo;
    private final Map<String, Texture> cache = new HashMap<>();
    private boolean facingRight = true;
    private final float[] vertices = new float[16];
    private final int[] indices = { 0, 1, 2, 2, 3, 0 };

    public CharacterRenderer(Shader shader) {
        this.shader = shader;
        vao = glGenVertexArrays();
        vbo = glGenBuffers();
        ebo = glGenBuffers();

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, (long) vertices.length * Float.BYTES, GL_DYNAMIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
        var ib = BufferUtils.createIntBuffer(indices.length);
        ib.put(indices).flip();
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, ib, GL_STATIC_DRAW);

        int stride = 4 * Float.BYTES;
        glVertexAttribPointer(0, 2, GL_FLOAT, false, stride, 0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, stride, 2L * Float.BYTES);
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);
    }

    private void drawLayer(String path, float x, float y, float w, float h, Matrix4f proj, boolean facingRight) {
        if (path.contains("_-1.png")) return;

        Texture tex;
        if (cache.containsKey(path)) {
            tex = cache.get(path);
        } else {
            try {
                tex = new Texture(path);
                cache.put(path, tex);
            } catch (Exception e) {
                System.err.println("⚠️ عکس پیدا نشد: " + path);
                return;
            }
        }

        shader.use();
        shader.setMatrix("uProjection", proj);
        glActiveTexture(GL_TEXTURE0);
        tex.bind();
        shader.setInt("uTexture", 0);

        // 🌟 اینجا جادو میشه! مختصات U (افقی) رو برعکس میکنیم
        float u0 = facingRight ? 0f : 1f;
        float u1 = facingRight ? 1f : 0f;

        vertices[0] = x;         vertices[1] = y;         vertices[2] = u0; vertices[3] = 0;
        vertices[4] = x + w;     vertices[5] = y;         vertices[6] = u1; vertices[7] = 0;
        vertices[8] = x + w;     vertices[9] = y + h;     vertices[10] = u1; vertices[11] = 1;
        vertices[12] = x;        vertices[13] = y + h;    vertices[14] = u0; vertices[15] = 1;

        FloatBuffer fb = BufferUtils.createFloatBuffer(16);
        fb.put(vertices).flip();

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferSubData(GL_ARRAY_BUFFER, 0, fb);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
    }
    public void setFacingRight(boolean facingRight) {
        this.facingRight = facingRight;
    }
    public void render(Player player, float cx, float cy, Matrix4f projection) {
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glDisable(GL_CULL_FACE); // برای اینکه موقع برعکس شدن، غیب نشه

        // 🌟 جهت رو مستقیماً از بازیکن می‌خونیم
        boolean facingRight = player.facingRight;

        String p = "assets/textures/caracter/";
        float w = 64f;
        float h = 64f;
        float x = cx - w / 2f;
        float y = cy - h / 2f;

        // 🌟 به جای drawLayer قبلی، از این استفاده کن و facingRight رو بهش پاس بده
        drawLayer(p + "base/base_" + player.appearance.baseId + ".png", x, y, w, h, projection, facingRight);
        drawLayer(p + "pants/pants_" + player.appearance.pantsId + ".png", x, y, w, h, projection, facingRight);
        drawLayer(p + "shirts/shirt_" + player.appearance.shirtId + ".png", x, y, w, h, projection, facingRight);
        drawLayer(p + "boots/boots_" + player.appearance.bootsId + ".png", x, y, w, h, projection, facingRight);
        drawLayer(p + "hair/hair_" + player.appearance.hairId + ".png", x, y, w, h, projection, facingRight);
        drawLayer(p + "hats/hat_" + player.appearance.hatId + ".png", x, y, w, h, projection, facingRight);
        drawLayer(p + "accessories/acc_" + player.appearance.accId + ".png", x, y, w, h, projection, facingRight);

        glDisable(GL_BLEND);
        glEnable(GL_CULL_FACE);
    }
    public void destroy() {
        for (Texture t : cache.values()) t.destroy();
        glDeleteBuffers(vbo);
        glDeleteBuffers(ebo);
        glDeleteVertexArrays(vao);
    }
}