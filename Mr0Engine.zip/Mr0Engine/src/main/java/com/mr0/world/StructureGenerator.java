package mr0.world;

import java.util.Random;

public class StructureGenerator {
    private final World world;

    public StructureGenerator(World world, long seed) {
        this.world = world;
    }

    public void tryGenerateStructure(Chunk chunk, int wx, int groundY, Biome biome) {
        long hash = ((long) wx * 341873128712L) ^ ((long) groundY * 132897987541L);
        Random localRng = new Random(hash);

        // شانس ساخت سازه (۵ درصد)
        if (localRng.nextFloat() > 0.05f) return;
        // جلوگیری از ساخت سازه روی سازه دیگه
        if (world.hasStructureNear(wx, groundY, 15)) return;

        switch (biome) {
            case SNOW: buildIgloo(chunk, wx, groundY); break;
            case DESERT: buildPyramid(chunk, wx, groundY); break;
            case PLAINS:
            case FOREST:
                // شانس 50-50 برای خانه یا قلعه
                if (localRng.nextBoolean()) buildHouse(chunk, wx, groundY);
                else buildCastle(chunk, wx, groundY);
                break;
            default: break;
        }
    }

    // ---- ساخت خانه (با استفاده از بلاک‌های جدید) ----
    private void buildHouse(Chunk chunk, int centerX, int groundY) {
        int cx = chunk.getChunkX() * Chunk.SIZE;
        int cy = chunk.getChunkY() * Chunk.SIZE;
        int width = 7, height = 6;

        for (int x = -width/2; x <= width/2; x++) {
            for (int y = 0; y < height; y++) {
                int wx = centerX + x;
                int wy = groundY + y;

                if (wx >= cx && wx < cx + Chunk.SIZE && wy >= cy && wy < cy + Chunk.SIZE) {
                    if (y == 0 && Math.abs(x) < width/2) { // دیوار آجری
                        world.setBlockAtTile(wx, wy, (short) 22);
                    } else if (y == height - 1) { // سقف سفالی
                        world.setBlockAtTile(wx, wy, (short) 21);
                    } else if (Math.abs(x) == width/2) { // دیوارهای کناری
                        if (x == 0 && y < 3) continue; // جای درب
                        world.setBlockAtTile(wx, wy, (short) 22);
                    }
                }
            }
        }
        // درب
        int doorX = centerX, doorY = groundY;
        if (doorX >= cx && doorX < cx + Chunk.SIZE && doorY >= cy && doorY < cy + Chunk.SIZE) {
            world.setBlockAtTile(doorX, doorY, (short) 18);
        }
        world.addStructure("House", centerX, groundY);
    }

    // ---- ساخت قلعه (بزرگتر و با استفاده از پله و برج) ----
    private void buildCastle(Chunk chunk, int centerX, int groundY) {
        int cx = chunk.getChunkX() * Chunk.SIZE;
        int cy = chunk.getChunkY() * Chunk.SIZE;
        int size = 11; // اندازه قلعه

        for (int x = -size/2; x <= size/2; x++) {
            for (int y = 0; y < 8; y++) {
                int wx = centerX + x;
                int wy = groundY + y;

                if (wx >= cx && wx < cx + Chunk.SIZE && wy >= cy && wy < cy + Chunk.SIZE) {
                    // دیوارهای اصلی
                    if (Math.abs(x) == size/2) {
                        if (y % 2 == 0) {
                            world.setBlockAtTile(wx, wy, (short) 23); // دیوار سفید
                        } else {
                            world.setBlockAtTile(wx, wy, (short) 22); // دیوار آجری
                        }
                    }
                    // پله‌های داخل
                    if (Math.abs(x) <= size/2 - 2 && y < 4) {
                        world.setBlockAtTile(wx, wy, (short) 20); // پله سنگی
                    }
                    // سقف
                    if (y == 7) {
                        world.setBlockAtTile(wx, wy, (short) 21); // سقف
                    }
                }
            }
        }
        // درب بزرگ قلعه
        int doorX = centerX, doorY = groundY;
        if (doorX >= cx && doorX < cx + Chunk.SIZE && doorY >= cy && doorY < cy + Chunk.SIZE) {
            world.setBlockAtTile(doorX, doorY, (short) 18);
            world.setBlockAtTile(doorX, doorY + 1, (short) 18);
            world.setBlockAtTile(doorX, doorY + 2, (short) 0);
        }
        world.addStructure("Castle", centerX, groundY);
    }

    // ---- ایگلو ----
    private void buildIgloo(Chunk chunk, int centerX, int groundY) {
        int cx = chunk.getChunkX() * Chunk.SIZE;
        int cy = chunk.getChunkY() * Chunk.SIZE;

        for (int x = -3; x <= 3; x++) {
            for (int y = 0; y <= 4; y++) {
                if (x*x + y*y <= 12) {
                    int wx = centerX + x;
                    int wy = groundY + y;
                    if (wx >= cx && wx < cx + Chunk.SIZE && wy >= cy && wy < cy + Chunk.SIZE) {
                        if (x*x + y*y > 6 || y == 0) {
                            world.setBlockAtTile(wx, wy, (short) 23); // سفید (شبیه یخ)
                        }
                    }
                }
            }
        }
        int doorX = centerX, doorY = groundY;
        if (doorX >= cx && doorX < cx + Chunk.SIZE && doorY >= cy && doorY < cy + Chunk.SIZE) {
            world.setBlockAtTile(doorX, doorY, (short) 0);
            world.setBlockAtTile(doorX, doorY + 1, (short) 0);
        }
        world.addStructure("Igloo", centerX, groundY);
    }

    // ---- هرم ----
    private void buildPyramid(Chunk chunk, int centerX, int groundY) {
        int cx = chunk.getChunkX() * Chunk.SIZE;
        int cy = chunk.getChunkY() * Chunk.SIZE;

        int baseSize = 7;
        for (int level = 0; level < baseSize / 2 + 1; level++) {
            int y = groundY + level;
            int halfWidth = baseSize / 2 - level;
            for (int x = -halfWidth; x <= halfWidth; x++) {
                int wx = centerX + x;
                if (wx >= cx && wx < cx + Chunk.SIZE && y >= cy && y < cy + Chunk.SIZE) {
                    if (Math.abs(x) == halfWidth || level == baseSize / 2) {
                        world.setBlockAtTile(wx, y, (short) 16); // آجر قرمز
                    }
                }
            }
        }
        int doorX = centerX, doorY = groundY;
        if (doorX >= cx && doorX < cx + Chunk.SIZE && doorY >= cy && doorY < cy + Chunk.SIZE) {
            world.setBlockAtTile(doorX, doorY, (short) 0);
            world.setBlockAtTile(doorX, doorY + 1, (short) 0);
        }
        world.addStructure("Pyramid", centerX, groundY);
    }
}