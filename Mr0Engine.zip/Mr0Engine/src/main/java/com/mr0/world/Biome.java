package mr0.world;

public enum Biome {
    PLAINS("plains", "assets/textures/backgrand/plains.png"),
    FOREST("forest", "assets/textures/backgrand/forest.png"),
    DESERT("desert", "assets/textures/backgrand/desert.png"),
    SNOW  ("snow",   "assets/textures/backgrand/snow.png");

    private final String name;
    private final String backgroundPath;

    Biome(String name, String backgroundPath) {
        this.name = name;
        this.backgroundPath = backgroundPath;
    }

    public String getName() { return name; }
    public String getBackgroundPath() { return backgroundPath; }
}