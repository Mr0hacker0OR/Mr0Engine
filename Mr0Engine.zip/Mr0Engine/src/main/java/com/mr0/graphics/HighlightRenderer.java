package mr0.graphics;

import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;

import java.nio.FloatBuffer;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

public class HighlightRenderer {

    private final int vao;
    private final int vbo;

    private final Shader shader;

    public HighlightRenderer(Shader shader) {
        this.shader = shader;

        vao = glGenVertexArrays();
        vbo = glGenBuffers();

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, 6 * 4 * Float.BYTES, GL_DYNAMIC_DRAW);

        int stride = 4 * Float.BYTES;
        glVertexAttribPointer(0, 2, GL_FLOAT, false, stride, 0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, stride, 2L * Float.BYTES);
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);
    }

    /**
     * Draws a translucent white outline box around the tile.
     * Uses a dedicated shader, or fallback to the given shader.
     */
    public void render(float tilePixelX, float tilePixelY, float tilePixelSize,
                       Matrix4f projection) {

        float t = 5.0f; // border thickness in pixels

        float x0 = tilePixelX;
        float y0 = tilePixelY;
        float x1 = tilePixelX + tilePixelSize;
        float y1 = tilePixelY + tilePixelSize;

        float[] v = new float[]{
                // bottom
                x0, y0, 0f, 0f,
                x1, y0, 1f, 0f,
                x1, y0 + t, 1f, 1f,
                x0, y0, 0f, 0f,
                x1, y0 + t, 1f, 1f,
                x0, y0 + t, 0f, 1f,

                // top
                x0, y1 - t, 0f, 0f,
                x1, y1 - t, 1f, 0f,
                x1, y1, 1f, 1f,
                x0, y1 - t, 0f, 0f,
                x1, y1, 1f, 1f,
                x0, y1, 0f, 1f,

                // left
                x0, y0, 0f, 0f,
                x0 + t, y0, 1f, 0f,
                x0 + t, y1, 1f, 1f,
                x0, y0, 0f, 0f,
                x0 + t, y1, 1f, 1f,
                x0, y1, 0f, 1f,

                // right
                x1 - t, y0, 0f, 0f,
                x1, y0, 1f, 0f,
                x1, y1, 1f, 1f,
                x1 - t, y0, 0f, 0f,
                x1, y1, 1f, 1f,
                x1 - t, y1, 0f, 1f,
        };

        FloatBuffer fb = BufferUtils.createFloatBuffer(v.length);
        fb.put(v).flip();

        shader.use();
        shader.setMatrix("uProjection", projection);

        // blend override
        glDisable(GL_TEXTURE_2D); // just in case

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferSubData(GL_ARRAY_BUFFER, 0, fb);

        glDrawArrays(GL_TRIANGLES, 0, v.length / 4);
        glBindVertexArray(0);

        glEnable(GL_TEXTURE_2D);
    }

    public void destroy() {
        glDeleteBuffers(vbo);
        glDeleteVertexArrays(vao);
    }
}