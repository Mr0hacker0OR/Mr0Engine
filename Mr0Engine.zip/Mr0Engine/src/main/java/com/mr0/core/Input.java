package mr0.core;

import org.lwjgl.BufferUtils;

import java.nio.DoubleBuffer;

import static org.lwjgl.glfw.GLFW.*;

public class Input {

    private final long window;

    private final boolean[] keys = new boolean[GLFW_KEY_LAST + 1];

    private double mouseX;
    private double mouseY;

    private boolean mouseLeftDown;
    private boolean mouseRightDown;
    private boolean mouseLeftPressed;   // one-shot
    private boolean mouseRightPressed;  // one-shot

    private double scrollY;
    public boolean isKeyPressed(int key) {
        // one-shot: true فقط اولین فریم
        return keys[key] && !prevKeys[key];
    }
    private final boolean[] prevKeys = new boolean[GLFW_KEY_LAST + 1];
    public Input(long window) {
        this.window = window;
    }

    /** Call once per frame (before update logic). */
    public void poll() {
        System.arraycopy(keys, 0, prevKeys, 0, keys.length);
        for (int k = 0; k <= GLFW_KEY_LAST; k++) {
            keys[k] = glfwGetKey(window, k) == GLFW_PRESS;
        }
        DoubleBuffer xb = BufferUtils.createDoubleBuffer(1);
        DoubleBuffer yb = BufferUtils.createDoubleBuffer(1);
        glfwGetCursorPos(window, xb, yb);
        mouseX = xb.get(0);
        mouseY = yb.get(0);
    }

    /** Call at END of frame to reset one-shot. */
    public void endFrame() {
        mouseLeftPressed = false;
        mouseRightPressed = false;
        scrollY = 0;
    }

    public void handleMouseButton(int button, int action) {
        if (button == GLFW_MOUSE_BUTTON_LEFT) {
            if (action == GLFW_PRESS) { mouseLeftDown = true; mouseLeftPressed = true; }
            else if (action == GLFW_RELEASE) mouseLeftDown = false;
        }
        if (button == GLFW_MOUSE_BUTTON_RIGHT) {
            if (action == GLFW_PRESS) { mouseRightDown = true; mouseRightPressed = true; }
            else if (action == GLFW_RELEASE) mouseRightDown = false;
        }
    }

    public void handleScroll(double dy) {
        scrollY += dy;
    }

    public boolean isKeyDown(int key) { return keys[key]; }
    public boolean isLeftDown() { return mouseLeftDown; }
    public boolean isRightDown() { return mouseRightDown; }
    public boolean isLeftPressed() { return mouseLeftPressed; }
    public boolean isRightPressed() { return mouseRightPressed; }

    public double getMouseX() { return mouseX; }
    public double getMouseY() { return mouseY; }
    public double getScrollY() { return scrollY; }
}