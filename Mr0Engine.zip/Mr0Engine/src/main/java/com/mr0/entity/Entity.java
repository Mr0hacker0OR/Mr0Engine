package mr0.entity;

import mr0.world.World;

/**
 * Base entity with AABB physics in pixel space.
 * (x, y) = top-left corner. y up is positive.
 */
public abstract class Entity {

    public float x;
    public float y;

    public float width;
    public float height;

    public float vx;
    public float vy;

    public boolean onGround;

    public Entity(float x, float y, float w, float h) {
        this.x = x;
        this.y = y;
        this.width = w;
        this.height = h;
    }

    public float centerX() { return x + width * 0.5f; }
    public float centerY() { return y + height * 0.5f; }

    /**
     * Apply gravity + integrate + resolve tile collisions.
     */
    protected void physics(World world, float dt, float gravity, float maxFallSpeed) {

        // gravity
        vy -= gravity * dt;
        if (vy < -maxFallSpeed) vy = -maxFallSpeed;

        // X then Y
        moveX(world, vx * dt);
        moveY(world, vy * dt);
    }

    // ---------- X axis ----------
    private void moveX(World world, float dx) {

        if (dx == 0) return;

        int ts = World.tileSize();
        float newX = x + dx;

        // vertical span of entity
        int topTile    = (int) Math.floor((y + 0.001f) / ts);
        int bottomTile = (int) Math.floor((y + height - 0.001f) / ts);

        if (dx > 0) {
            int rightTile = (int) Math.floor((newX + width - 0.001f) / ts);
            int oldRight  = (int) Math.floor((x + width - 0.001f) / ts);

            // Only check new tiles we enter
            if (rightTile > oldRight) {
                for (int ty = topTile; ty <= bottomTile; ty++) {
                    if (world.isSolidTile(rightTile, ty)) {
                        newX = rightTile * ts - width;
                        vx = 0;
                        break;
                    }
                }
            }
        } else {
            int leftTile = (int) Math.floor(newX / ts);
            int oldLeft  = (int) Math.floor(x / ts);

            if (leftTile < oldLeft) {
                for (int ty = topTile; ty <= bottomTile; ty++) {
                    if (world.isSolidTile(leftTile, ty)) {
                        newX = (leftTile + 1) * ts;
                        vx = 0;
                        break;
                    }
                }
            }
        }

        x = newX;
    }

    // ---------- Y axis ----------
    private void moveY(World world, float dy) {

        int ts = World.tileSize();

        onGround = false;

        if (dy == 0) {
            // still need to detect if standing on ground even when stationary
            checkGroundOnly(world);
            return;
        }

        float newY = y + dy;

        int leftTile  = (int) Math.floor((x + 0.001f) / ts);
        int rightTile = (int) Math.floor((x + width - 0.001f) / ts);

        if (dy < 0) {
            // moving DOWN
            int bottomTile = (int) Math.floor(newY / ts);
            int oldBottom  = (int) Math.floor(y / ts);

            if (bottomTile < oldBottom) {
                for (int tx = leftTile; tx <= rightTile; tx++) {
                    if (world.isSolidTile(tx, bottomTile)) {
                        // stand on top of that tile: y = top edge of tile - height
                        newY = bottomTile * ts + ts; // = top of the tile above bottomTile
                        newY = (bottomTile + 1) * ts; // wait, fix below
                        // Correct: place bottom of entity at TOP of solid tile
                        // solid tile occupies [bottomTile * ts, (bottomTile+1) * ts]
                        // top of that tile is (bottomTile+1) * ts
                        newY = (bottomTile + 1) * ts;
                        vy = 0;
                        onGround = true;
                        break;
                    }
                }
            } else {
                // didn't cross tile boundary but maybe resting exactly on it
                // check tile just below feet
                int belowTile = (int) Math.floor((newY - 0.001f) / ts);
                if (belowTile < oldBottom) {
                    for (int tx = leftTile; tx <= rightTile; tx++) {
                        if (world.isSolidTile(tx, belowTile)) {
                            newY = (belowTile + 1) * ts;
                            vy = 0;
                            onGround = true;
                            break;
                        }
                    }
                }
            }
        } else {
            // moving UP
            int topTile = (int) Math.floor((newY + height) / ts);
            int oldTop  = (int) Math.floor((y + height) / ts);

            if (topTile > oldTop) {
                for (int tx = leftTile; tx <= rightTile; tx++) {
                    if (world.isSolidTile(tx, topTile)) {
                        newY = topTile * ts - height;
                        vy = 0;
                        break;
                    }
                }
            }
        }

        y = newY;
    }

    /** When dy == 0, still figure out if we're standing on ground. */
    private void checkGroundOnly(World world) {
        int ts = World.tileSize();
        int leftTile  = (int) Math.floor((x + 0.001f) / ts);
        int rightTile = (int) Math.floor((x + width - 0.001f) / ts);

        int belowTile = (int) Math.floor((y - 0.001f) / ts);

        for (int tx = leftTile; tx <= rightTile; tx++) {
            if (world.isSolidTile(tx, belowTile)) {
                onGround = true;
                return;
            }
        }
    }
}