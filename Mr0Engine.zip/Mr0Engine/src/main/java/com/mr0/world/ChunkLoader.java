package mr0.world;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ChunkLoader {

    private final World world;
    private final WorldGenerator generator;

    private final int viewDistance; // in chunks

    public ChunkLoader(World world, WorldGenerator generator, int viewDistance) {
        this.world = world;
        this.generator = generator;
        this.viewDistance = viewDistance;
    }

    /**
     * Load chunks around a world-pixel position, unload far ones.
     */
    public void update(float worldPixelX, float worldPixelY) {

        int chunkPixels = Chunk.SIZE * Chunk.TILE_SIZE;

        int centerCx = (int) Math.floor(worldPixelX / chunkPixels);
        int centerCy = (int) Math.floor(worldPixelY / chunkPixels);

        Set<Long> needed = new HashSet<>();

        for (int dx = -viewDistance; dx <= viewDistance; dx++) {
            for (int dy = -viewDistance; dy <= viewDistance; dy++) {

                int cx = centerCx + dx;
                int cy = centerCy + dy;

                needed.add(key(cx, cy));

                if (world.getChunk(cx, cy) == null) {
                    Chunk chunk = new Chunk(cx, cy);
                    world.addChunk(chunk);
                    generator.generate(chunk);

                }
            }
        }

        // Unload chunks outside view + 1 margin
        List<Chunk> toRemove = new ArrayList<>();

        for (Chunk chunk : world.getChunks()) {

            long k = key(chunk.getChunkX(), chunk.getChunkY());

            if (!needed.contains(k)) {
                int dx = Math.abs(chunk.getChunkX() - centerCx);
                int dy = Math.abs(chunk.getChunkY() - centerCy);

                if (dx > viewDistance + 1 || dy > viewDistance + 1) {
                    toRemove.add(chunk);
                }
            }
        }

        for (Chunk chunk : toRemove) {
            world.removeChunk(chunk);
        }
    }

    private long key(int x, int y) {
        return ((long) x << 32) | (y & 0xffffffffL);
    }
}