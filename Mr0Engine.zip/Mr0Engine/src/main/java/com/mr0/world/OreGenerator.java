package mr0.world;

import java.util.Random;

/**
 * Adds ore veins into stone blocks.
 * Only called after terrain generation.
 */
public class OreGenerator {

    // ore id, minY, maxY, veins per chunk, vein size range
    private static final int[][] ORE_DEFS = {
            // id, minY, maxY, veinsPerChunk, minSize, maxSize
            //   16(coal)     0     15    6          2        5
            //   17(iron)     0     12    4          2        4
            //   18(gold)     0      8    2          1        3
            //   19(diamond)  0      4    1          1        2
    };

    private final Random rng;

    public OreGenerator(long seed) {
        this.rng = new Random(seed);
    }

    /**
     * Add ores to a chunk. Should be called once after terrain is done.
     */
    public void generate(Chunk chunk) {

        // seed rng by chunk coords for determinism
        Random chunkRng = new Random(
                ((long) chunk.getChunkX() * 341873128712L) ^
                        ((long) chunk.getChunkY() * 132897987541L) ^
                        rng.nextLong()
        );

        spawnOre(chunk, chunkRng, (short) 16, 0, 15, 6, 2, 5); // coal
        spawnOre(chunk, chunkRng, (short) 17, 0, 12, 4, 2, 4); // iron
        spawnOre(chunk, chunkRng, (short) 18, 0,  8, 2, 1, 3); // gold
        spawnOre(chunk, chunkRng, (short) 19, 0,  4, 1, 1, 2); // diamond
    }

    private void spawnOre(Chunk chunk, Random rng, short oreId,
                          int minY, int maxY, int veins,
                          int minSize, int maxSize) {

        int chunkWorldX = chunk.getChunkX() * Chunk.SIZE;
        int chunkWorldY = chunk.getChunkY() * Chunk.SIZE;

        for (int v = 0; v < veins; v++) {

            // pick random spot in chunk
            int lx = rng.nextInt(Chunk.SIZE);
            int ly = rng.nextInt(Chunk.SIZE);

            int wy = chunkWorldY + ly;
            if (wy < minY || wy > maxY) continue;

            // must be stone
            if (chunk.getBlock(lx, ly) != 3) continue;

            // build a small blob
            int size = minSize + rng.nextInt(maxSize - minSize + 1);

            int cx = lx;
            int cy = ly;

            for (int s = 0; s < size; s++) {
                if (cx >= 0 && cx < Chunk.SIZE && cy >= 0 && cy < Chunk.SIZE) {
                    if (chunk.getBlock(cx, cy) == 3) {
                        chunk.setBlock(cx, cy, oreId);
                    }
                }
                // random walk
                int dir = rng.nextInt(4);
                switch (dir) {
                    case 0: cx++; break;
                    case 1: cx--; break;
                    case 2: cy++; break;
                    case 3: cy--; break;
                }
            }
        }
    }
}