package mr0.graphics;

import org.joml.Matrix4f;

public class Camera {

    private float x;
    private float y;
    private float zoom = 1.0f;

    // smooth follow
    private float targetX;
    private float targetY;

    public Matrix4f getProjection(int width, int height) {
        // اینجا دیگه نباید از اعداد ثابت استفاده بشه، width و height همون‌هایی هستن که از Engine میان
        float halfW = width / (2.0f * zoom);
        float halfH = height / (2.0f * zoom);

        return new Matrix4f().ortho(
                x - halfW, x + halfW,
                y - halfH, y + halfH,
                -1.0f, 1.0f
        );
    }

    public void follow(float cx, float cy, float dt) {
        targetX = cx;
        targetY = cy;
        // lerp
        float k = Math.min(1f, 10f * dt);
        x += (targetX - x) * k;
        y += (targetY - y) * k;
    }

    public void setImmediate(float cx, float cy) {
        this.x = cx;
        this.y = cy;
        this.targetX = cx;
        this.targetY = cy;
    }

    public void setZoom(float zoom) {
        this.zoom = Math.max(0.25f, Math.min(zoom, 4f));
    }

    public float getX() { return x; }
    public float getY() { return y; }
    public float getZoom() { return zoom; }
}