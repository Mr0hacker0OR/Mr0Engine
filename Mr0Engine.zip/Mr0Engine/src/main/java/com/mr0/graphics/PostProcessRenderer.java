package mr0.graphics;

import org.lwjgl.BufferUtils;
import java.nio.FloatBuffer;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

public class PostProcessRenderer {
    private int vao, vbo;
    private Shader shader;
    private int width, height;

    public PostProcessRenderer(Shader shader, int width, int height) {
        this.shader = shader;
        this.width = width;
        this.height = height;

        // ۶ گوشه (۲ مثلث مستقل) برای پر کردن کل صفحه بدون باگ
        float[] vertices = {
                // مثلث اول (پایین-راست)
                -1f, -1f,  0f, 0f,
                1f, -1f,  1f, 0f,
                1f,  1f,  1f, 1f,
                // مثلث دوم (بالا-چپ)
                -1f, -1f,  0f, 0f,
                1f,  1f,  1f, 1f,
                -1f,  1f,  0f, 1f
        };

        vao = glGenVertexArrays();
        vbo = glGenBuffers();

        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);

        FloatBuffer fb = BufferUtils.createFloatBuffer(vertices.length);
        fb.put(vertices).flip();
        glBufferData(GL_ARRAY_BUFFER, fb, GL_STATIC_DRAW);

        int stride = 4 * Float.BYTES;
        glVertexAttribPointer(0, 2, GL_FLOAT, false, stride, 0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, stride, 2L * Float.BYTES);
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);
    }

    // به جای render قبلی
    public void render(int screenTexture, int shaderMode, float timeOfDay) {
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_BLEND);
        glDisable(GL_CULL_FACE);

        glClearColor(0f, 0f, 0f, 1f);
        glClear(GL_COLOR_BUFFER_BIT);

        shader.use();
        shader.setInt("uMode", shaderMode);
        shader.setVec2("uResolution", width, height);
        shader.setFloat("uTimeOfDay", timeOfDay); // 🌟 پاس دادن زمان به شیدر

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, screenTexture);
        shader.setInt("uScreenTexture", 0);

        glBindVertexArray(vao);
        glDrawArrays(GL_TRIANGLES, 0, 6);
        glBindVertexArray(0);

        glEnable(GL_CULL_FACE);
    }
}