package mr0.graphics;

import mr0.world.Chunk;
import mr0.world.World;
import mr0.world.ItemDrop;
import mr0.world.Block;
import mr0.world.BlockRegistry;

import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Map;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

public class Renderer {

    private final Shader shader;
    private final Texture texture;
    private final TreeRenderer treeRenderer;
    private final Map<Long, ChunkMesh> meshes = new HashMap<>();

    // 🌟 فیلدها برای سیستم بک‌گراند
    private BackgroundRenderer backgroundRenderer;

    public Renderer(Shader shader, Texture texture) {
        this(shader, texture, null);
    }

    public Renderer(Shader shader, Texture texture, TreeRenderer treeRenderer) {
        this.shader = shader;
        this.texture = texture;
        this.treeRenderer = treeRenderer;
    }

    public void initBackground(Shader bgShader) {
        this.backgroundRenderer = new BackgroundRenderer(bgShader);
    }

    public void setBiome(String biomeName, String texturePath) {
        if (backgroundRenderer != null) {
            backgroundRenderer.setBiome(biomeName, texturePath);
        }
    }

    private long key(int x, int y) {
        return ((long) x << 32) | (y & 0xffffffffL);
    }

    public void beginFrame(int width, int height) {
        glClearColor(0.42f, 0.68f, 0.95f, 1f);
        glClear(GL_COLOR_BUFFER_BIT);

        if (backgroundRenderer != null) {
            backgroundRenderer.render();
        }
    }

    public void renderWorld(World world, Camera camera, int width, int height) {
        shader.use();
        shader.setMatrix("uProjection", camera.getProjection(width, height));

        glActiveTexture(GL_TEXTURE0);
        texture.bind();
        shader.setInt("uTexture", 0);

        // Cleanup stale chunk meshes
        meshes.keySet().removeIf(id -> {
            boolean exists = world.getChunks().stream()
                    .anyMatch(chunk -> key(chunk.getChunkX(), chunk.getChunkY()) == id);
            if (!exists) {
                ChunkMesh mesh = meshes.get(id);
                if (mesh != null) mesh.destroy();
            }
            return !exists;
        });

        // Pass 1: Walls
        for (Chunk chunk : world.getChunks()) {
            long id = key(chunk.getChunkX(), chunk.getChunkY());
            ChunkMesh mesh = meshes.computeIfAbsent(id, k -> new ChunkMesh());
            if (chunk.isWallsDirty()) {
                mesh.buildWalls(chunk);
                chunk.clearWallsDirty();
            }
            mesh.renderWalls();
        }

        // Pass 2: Foreground blocks
        for (Chunk chunk : world.getChunks()) {
            long id = key(chunk.getChunkX(), chunk.getChunkY());
            ChunkMesh mesh = meshes.get(id);
            if (chunk.isDirty()) {
                mesh.buildForeground(chunk);
                chunk.clearDirty();
            }
            mesh.renderForeground();
        }

        // Pass 3: Trees
        if (treeRenderer != null) {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
            treeRenderer.render(world);
            glDisable(GL_BLEND);
        }
    }

    // 🌟 متد جدید برای کشیدن آیتم‌ها
    public void renderItems(World world, Camera camera, int width, int height) {
        if (world.getItemDrops().isEmpty()) return;

        Matrix4f proj = camera.getProjection(width, height);
        shader.use();
        shader.setMatrix("uProjection", proj);
        glActiveTexture(GL_TEXTURE0);
        texture.bind();
        shader.setInt("uTexture", 0);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        for (ItemDrop drop : world.getItemDrops()) {
            float bob = (float) Math.sin(drop.lifeTime * 5f) * 4f;
            float size = 16f;
            float x = drop.x - size / 2f;
            float y = drop.y - size / 2f + bob;

            int tileSize = BlockRegistry.TILE_SIZE;
            int cols = BlockRegistry.ATLAS_COLUMNS;
            int rows = BlockRegistry.ATLAS_ROWS;
            float atlasW = cols * tileSize;
            float atlasH = rows * tileSize;

            Block block = BlockRegistry.get(drop.blockId);
            int tileIndex = block != null ? block.sideTile : -1;
            if (tileIndex < 0) continue;

            int col = tileIndex % cols;
            int row = tileIndex / cols;

            float u0 = (col * tileSize + 0.5f) / atlasW;
            float u1 = ((col + 1) * tileSize - 0.5f) / atlasW;
            float v0 = 1f - ((row + 1) * tileSize - 0.5f) / atlasH;
            float v1 = 1f - (row * tileSize + 0.5f) / atlasH;

            float[] vertices = {
                    x, y,         u0, v0,
                    x + size, y,  u1, v0,
                    x + size, y + size, u1, v1,
                    x, y + size,  u0, v1
            };
            int[] indices = { 0, 1, 2, 2, 3, 0 };

            int vao = glGenVertexArrays();
            int vbo = glGenBuffers();
            int ebo = glGenBuffers();

            glBindVertexArray(vao);
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            FloatBuffer vb = BufferUtils.createFloatBuffer(vertices.length);
            vb.put(vertices).flip();
            glBufferData(GL_ARRAY_BUFFER, vb, GL_DYNAMIC_DRAW);

            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
            IntBuffer ib = BufferUtils.createIntBuffer(indices.length);
            ib.put(indices).flip();
            glBufferData(GL_ELEMENT_ARRAY_BUFFER, ib, GL_DYNAMIC_DRAW);

            int stride = 4 * Float.BYTES;
            glVertexAttribPointer(0, 2, GL_FLOAT, false, stride, 0);
            glEnableVertexAttribArray(0);
            glVertexAttribPointer(1, 2, GL_FLOAT, false, stride, 2L * Float.BYTES);
            glEnableVertexAttribArray(1);

            glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);

            glDeleteBuffers(vbo);
            glDeleteBuffers(ebo);
            glDeleteVertexArrays(vao);
        }
        glDisable(GL_BLEND);
    }

    public Texture getTexture() { return texture; }
    public Shader getShader() { return shader; }

    public void destroy() {
        for (ChunkMesh mesh : meshes.values()) mesh.destroy();
        meshes.clear();
        if (treeRenderer != null) treeRenderer.destroy();
        if (backgroundRenderer != null) backgroundRenderer.destroy();
        texture.destroy();
        shader.destroy();
    }
}