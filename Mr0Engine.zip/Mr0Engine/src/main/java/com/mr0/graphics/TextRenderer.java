package mr0.graphics;

import org.lwjgl.BufferUtils;
import org.lwjgl.stb.STBTTBakedChar;
import org.lwjgl.stb.STBTruetype;
import org.lwjgl.system.MemoryStack;
import org.joml.Matrix4f;

import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

public class TextRenderer {
    private final Shader shader;
    private final int vao, vbo, texture;
    private final STBTTBakedChar.Buffer cdata;
    private static final int BITMAP_W = 1024, BITMAP_H = 1024; // بزرگترش کردم که فونت ۱۰۰٪ جا بشه

    public TextRenderer(Shader shader, String fontPath, int fontSize) throws Exception {
        this.shader = shader;

        System.out.println("⏳ در حال لود کردن فونت از مسیر: " + fontPath);
        byte[] fontData = Files.readAllBytes(Path.of(fontPath));
        ByteBuffer ttf = BufferUtils.createByteBuffer(fontData.length);
        ttf.put(fontData).flip();

        ByteBuffer bitmap = BufferUtils.createByteBuffer(BITMAP_W * BITMAP_H);
        cdata = STBTTBakedChar.malloc(96);

        int result = STBTruetype.stbtt_BakeFontBitmap(ttf, fontSize, bitmap, BITMAP_W, BITMAP_H, 32, cdata);
        System.out.println("✅ نتیجه لود فونت: " + result + " (اگر منفی بود یعنی فونت جا نشده)");

        texture = glGenTextures();
        glBindTexture(GL_TEXTURE_2D, texture);

        glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

        // 🌟 استفاده از GL_R8 به جای GL_RED برای فرمت داخلی
        glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, BITMAP_W, BITMAP_H, 0, GL_RED, GL_UNSIGNED_BYTE, bitmap);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        vao = glGenVertexArrays();
        vbo = glGenBuffers();
        glBindVertexArray(vao);
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, (long) 6 * 4 * 1024 * Float.BYTES, GL_DYNAMIC_DRAW);

        glVertexAttribPointer(0, 2, GL_FLOAT, false, 4 * Float.BYTES, 0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, 4 * Float.BYTES, 2L * Float.BYTES);
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);
    }

    public void drawText(String text, float x, float y, float scale, Matrix4f proj, float r, float g, float b, float a) {
        if (text == null || text.isEmpty()) return;

        // 🌟 خاموش کردن تست عمق و حذف وجه‌ها که متن حتما دیده بشه
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_CULL_FACE);

        shader.use();
        shader.setMatrix("uProjection", proj);
        shader.setVec4("uColor", r, g, b, a);

        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_2D, texture);
        shader.setInt("uTexture", 0);

        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        glBindVertexArray(vao);

        try (MemoryStack stack = MemoryStack.stackPush()) {
            FloatBuffer vertices = stack.mallocFloat(6 * 4 * text.length());
            float xpos = x;

            for (int i = 0; i < text.length(); i++) {
                int c = text.charAt(i) - 32;
                if (c < 0 || c >= 96) continue;

                STBTTBakedChar charData = cdata.get(c);
                float x0 = xpos + charData.xoff() * scale;
                float y0 = y + charData.yoff() * scale;
                float x1 = x0 + (charData.x1() - charData.x0()) * scale;
                float y1 = y0 + (charData.y1() - charData.y0()) * scale;

                float u0 = (float) charData.x0() / BITMAP_W;
                float v0 = (float) charData.y0() / BITMAP_H;
                float u1 = (float) charData.x1() / BITMAP_W;
                float v1 = (float) charData.y1() / BITMAP_H;

                vertices.put(x0).put(y0).put(u0).put(v0);
                vertices.put(x1).put(y0).put(u1).put(v0);
                vertices.put(x1).put(y1).put(u1).put(v1);

                vertices.put(x0).put(y0).put(u0).put(v0);
                vertices.put(x1).put(y1).put(u1).put(v1);
                vertices.put(x0).put(y1).put(u0).put(v1);

                xpos += charData.xadvance() * scale;
            }
            vertices.flip();

            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            glBufferSubData(GL_ARRAY_BUFFER, 0, vertices);
            glDrawArrays(GL_TRIANGLES, 0, 6 * text.length());
        }
        glBindVertexArray(0);
        glDisable(GL_BLEND);

        // دوباره برگردوندن حالت عمق برای بقیه بازی (اگه نیاز باشه)
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_CULL_FACE);
    }

    public void destroy() {
        glDeleteTextures(texture);
        glDeleteBuffers(vbo);
        glDeleteVertexArrays(vao);
    }
}