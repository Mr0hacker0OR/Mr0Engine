package mr0.core;

import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;

public class Window {

    private long handle;

    private final int width;
    private final int height;

    private Input input;

    public Window(int width, int height, String title) {

        this.width = width;
        this.height = height;

        GLFWErrorCallback.createPrint(System.err).set();

        if (!glfwInit()) throw new IllegalStateException("Unable to initialize GLFW");

        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
        glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GLFW_TRUE);

        handle = glfwCreateWindow(width, height, title, 0, 0);
        if (handle == 0) throw new RuntimeException("Failed to create window");

        glfwMakeContextCurrent(handle);
        glfwSwapInterval(1);
        GL.createCapabilities();
        glViewport(0, 0, width, height);
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

        input = new Input(handle);

        glfwSetMouseButtonCallback(handle, (win, button, action, mods) -> {
            input.handleMouseButton(button, action);
        });
        glfwSetScrollCallback(handle, (win, xoff, yoff) -> {
            input.handleScroll(yoff);
        });
    }

    public boolean shouldClose() { return glfwWindowShouldClose(handle); }

    public void update() {
        glfwSwapBuffers(handle);
        glfwPollEvents();
    }

    public long getHandle() { return handle; }
    public Input getInput() { return input; }
    public int getWidth() {
        int[] w = new int[1];
        int[] h = new int[1];
        org.lwjgl.glfw.GLFW.glfwGetWindowSize(handle, w, h);
        return w[0];
    }
    public int getHeight() {
        int[] w = new int[1];
        int[] h = new int[1];
        org.lwjgl.glfw.GLFW.glfwGetWindowSize(handle, w, h);
        return h[0];
    }

    public void destroy() {
        glfwDestroyWindow(handle);
        glfwTerminate();
    }
}