
package mr0;

import mr0.core.Engine;

public class Main {

    public static void main(String[] args)
            throws Exception {

        Engine engine = new Engine();

        engine.start();
    }
}