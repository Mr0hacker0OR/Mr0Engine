package mr0.world;

public class Tree {

    public enum Type {
        OAK_0, OAK_1, OAK_2, OAK_3,
        PINE_0, PINE_1,
        DEAD_0, DEAD_1
    }

    public final int baseX;          // مختصات تایل پای درخت (وسط تنه)
    public final int baseY;          // سطحی که درخت روش ایستاده
    public final Type type;

    // ارتفاع فعلی درخت (از پایین به بالا). وقتی قطع می‌شه کم می‌شه
    public int currentHeight;        // به پیکسل (نه تایل)
    public final int fullHeight;     // ارتفاع کامل اسپرایت

    public boolean isChopped = false;
    public boolean removed = false;

    // برای سیستم قطع کردن
    public int health = 5;           // چند ضربه نیاز داره

    public Tree(int baseX, int baseY, Type type, int fullHeight) {
        this.baseX = baseX;
        this.baseY = baseY;
        this.type = type;
        this.fullHeight = fullHeight;
        this.currentHeight = fullHeight;
    }

    /** آیا این نقطه (به پیکسل دنیا) داخل درخت هست؟ */
    public boolean contains(int worldPixelX, int worldPixelY) {
        int treePixelX = baseX * World.tileSize();
        int treePixelY = baseY * World.tileSize();

        // فرض می‌کنیم عرض درخت ۶۴ پیکسل هست و از وسط تراز شده
        int left = treePixelX - 32;
        int right = treePixelX + 32;
        int bottom = treePixelY;
        int top = treePixelY - currentHeight;

        return worldPixelX >= left && worldPixelX < right &&
                worldPixelY >= top && worldPixelY <= bottom;
    }

    /** ارتفاع نسبی نقطه ضربه از پایین درخت (۰ = پایین، fullHeight = بالا) */
    public int getHitHeight(int worldPixelY) {
        int treePixelY = baseY * World.tileSize();
        return treePixelY - worldPixelY;
    }
}