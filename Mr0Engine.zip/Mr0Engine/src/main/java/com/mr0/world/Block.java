package mr0.world;

public class Block {
    public boolean hasGravity = false; // اگه true باشه، بلاک میفته پایین
    public final short id;
    public final String name;
    public final boolean solid;

    public final int topTile;
    public final int sideTile;
    public final int bottomTile;

    public Block(short id, String name, boolean solid,
                 int topTile, int sideTile, int bottomTile) {
        this.id = id;
        this.name = name;
        this.solid = solid;
        this.topTile = topTile;
        this.sideTile = sideTile;
        this.bottomTile = bottomTile;
    }

    public boolean isAir() {
        return id == 0;
    }
}