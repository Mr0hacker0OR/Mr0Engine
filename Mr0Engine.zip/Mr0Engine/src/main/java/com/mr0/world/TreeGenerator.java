package mr0.world;

import java.util.Random;

public class TreeGenerator {

    private final World world;

    // ارتفاع اسپرایت درخت‌ها (باید با چیزی که در پایتون ساختی یکی باشه)
    private static final int TREE_PIXEL_HEIGHT = 96;

    public TreeGenerator(World world) {
        this.world = world;
    }

    public void tryPlaceTree(Chunk chunk, int wx, int wy, Biome biome) {
        long hash = ((long) wx * 73856093L) ^ ((long) wy * 19349663L);
        Random rng = new Random(hash);

        float chance;
        switch (biome) {
            case FOREST: chance = 0.13f; break;
            case PLAINS: chance = 0.025f; break;
            case SNOW:   chance = 0.07f; break;
            case DESERT: chance = 0.02f; break;
            default:     chance = 0.04f;
        }

        if (rng.nextFloat() > chance) return;

        // جلوگیری از قرار گرفتن درخت روی هم
        if (world.hasTreeNear(wx, wy, 3)) return;

        switch (biome) {
            case FOREST:
            case PLAINS:
                placeOak(wx, wy, rng);
                break;
            case SNOW:
                placePine(wx, wy, rng);
                break;
            case DESERT:
                placeCactus(wx, wy, rng);   // کاکتوس همچنان بلاکی بمونه
                break;
        }
    }

    private void placeOak(int wx, int wy, Random rng) {
        Tree.Type type;
        int r = rng.nextInt(4);
        switch (r) {
            case 0: type = Tree.Type.OAK_0; break;
            case 1: type = Tree.Type.OAK_1; break;
            case 2: type = Tree.Type.OAK_2; break;
            default: type = Tree.Type.OAK_3; break;
        }
        world.addTree(new Tree(wx, wy, type, TREE_PIXEL_HEIGHT));
    }

    private void placePine(int wx, int wy, Random rng) {
        Tree.Type type = rng.nextBoolean() ? Tree.Type.PINE_0 : Tree.Type.PINE_1;
        world.addTree(new Tree(wx, wy, type, TREE_PIXEL_HEIGHT));
    }

    private void placeCactus(int wx, int wy, Random rng) {
        int height = 3 + rng.nextInt(3);
        for (int i = 1; i <= height; i++) {
            short id = (i == height) ? (short) 15 : (short) 14;
            world.setBlockAtTile(wx, wy + i, id);
        }
    }
}