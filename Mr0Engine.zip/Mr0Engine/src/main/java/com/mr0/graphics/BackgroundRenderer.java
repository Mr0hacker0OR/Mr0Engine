package mr0.graphics;

import org.lwjgl.BufferUtils;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.util.HashMap;
import java.util.Map;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.*;

/**
 * Draws a full-screen textured quad for each biome.
 * Screen-space (NDC coords) so it always fills the viewport.
 */
public class BackgroundRenderer {

    private final Shader shader;
    private final int vao, vbo, ebo;

    private final Map<String, Texture> textures = new HashMap<>();
    private Texture currentTexture = null;
    private String currentBiome = null;

    // Full-screen quad in NDC: (-1..1)
    // x, y, u, v
    private static final float[] VERTICES = {
            -1f, -1f,  0f, 0f,
            1f, -1f,  1f, 0f,
            1f,  1f,  1f, 1f,
            -1f,  1f,  0f, 1f,
    };
    private static final int[] INDICES = { 0, 1, 2,  2, 3, 0 };

    public BackgroundRenderer(Shader shader) {
        this.shader = shader;

        vao = glGenVertexArrays();
        vbo = glGenBuffers();
        ebo = glGenBuffers();

        glBindVertexArray(vao);

        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        FloatBuffer vb = BufferUtils.createFloatBuffer(VERTICES.length);
        vb.put(VERTICES).flip();
        glBufferData(GL_ARRAY_BUFFER, vb, GL_STATIC_DRAW);

        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
        IntBuffer ib = BufferUtils.createIntBuffer(INDICES.length);
        ib.put(INDICES).flip();
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, ib, GL_STATIC_DRAW);

        int stride = 4 * Float.BYTES;
        glVertexAttribPointer(0, 2, GL_FLOAT, false, stride, 0);
        glEnableVertexAttribArray(0);
        glVertexAttribPointer(1, 2, GL_FLOAT, false, stride, 2L * Float.BYTES);
        glEnableVertexAttribArray(1);

        glBindVertexArray(0);
    }

    /**
     * Call this from your game loop whenever the player's biome changes.
     * texturePath example: "assets/textures/backgrand/forest.png"
     */
    public void setBiome(String biomeName, String texturePath) {
        if (biomeName.equals(currentBiome)) return; // already active
        currentBiome = biomeName;
        currentTexture = textures.computeIfAbsent(
                biomeName,
                k -> new Texture(texturePath)
        );
    }

    public void render() {
        if (currentTexture == null) return;

        shader.use();

        glActiveTexture(GL_TEXTURE0);
        currentTexture.bind();
        shader.setInt("uTexture", 0);

        glBindVertexArray(vao);
        glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_INT, 0);
        glBindVertexArray(0);
    }

    public void destroy() {
        glDeleteBuffers(vbo);
        glDeleteBuffers(ebo);
        glDeleteVertexArrays(vao);
        for (Texture t : textures.values()) t.destroy();
        textures.clear();
    }
}