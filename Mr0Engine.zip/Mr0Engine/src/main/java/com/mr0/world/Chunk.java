package mr0.world;

public class Chunk {

    public static final int SIZE = 32;
    public static final int TILE_SIZE = 16;

    private final int chunkX;
    private final int chunkY;

    private final short[] foreground = new short[SIZE * SIZE];
    private final short[] walls = new short[SIZE * SIZE];
    private final byte[] light = new byte[SIZE * SIZE];

    private boolean dirty = true;
    private boolean wallsDirty = true;

    public Chunk(int chunkX, int chunkY) {
        this.chunkX = chunkX;
        this.chunkY = chunkY;
    }

    private int index(int x, int y) {
        return y * SIZE + x;
    }

    // ---------- FOREGROUND ----------

    public short getBlock(int x, int y) {
        return foreground[index(x, y)];
    }

    public void setBlock(int x, int y, short id) {
        int i = index(x, y);
        if (foreground[i] != id) {
            foreground[i] = id;
            dirty = true;
        }
    }

    public short[] getBlocks() {
        return foreground;
    }

    // ---------- WALLS (background) ----------

    public short getWall(int x, int y) {
        return walls[index(x, y)];
    }

    public void setWall(int x, int y, short id) {
        int i = index(x, y);
        if (walls[i] != id) {
            walls[i] = id;
            wallsDirty = true;
        }
    }

    public short[] getWalls() {
        return walls;
    }

    // ---------- LIGHT ----------

    public byte getLight(int x, int y) { return light[index(x, y)]; }
    public void setLight(int x, int y, byte v) { light[index(x, y)] = v; }

    // ---------- DIRTY ----------

    public boolean isDirty() { return dirty; }
    public void clearDirty() { dirty = false; }
    public void markDirty() { dirty = true; }

    public boolean isWallsDirty() { return wallsDirty; }
    public void clearWallsDirty() { wallsDirty = false; }
    public void markWallsDirty() { wallsDirty = true; }

    // ---------- POSITION ----------

    public int getWorldX() { return chunkX * SIZE * TILE_SIZE; }
    public int getWorldY() { return chunkY * SIZE * TILE_SIZE; }
    public int getChunkX() { return chunkX; }
    public int getChunkY() { return chunkY; }
}