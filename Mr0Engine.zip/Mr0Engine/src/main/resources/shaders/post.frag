#version 330 core
out vec4 FragColor;
in vec2 TexCoords;
uniform sampler2D uScreenTexture;
uniform int uMode;
uniform vec2 uResolution;
uniform float uTimeOfDay; // 0.0 = ظهر, 0.5 = غروب, 0.75 = شب, 1.0 = صبح

void main() {
    vec3 color = texture(uScreenTexture, TexCoords).rgb;

    // 🌟 افکت شب و روز 🌟
    vec3 dayTint = vec3(1.0, 1.0, 1.0);       // روز (بدون تغییر)
    vec3 sunsetTint = vec3(1.0, 0.6, 0.4);    // غروب (نارنجی)
    vec3 nightTint = vec3(0.2, 0.3, 0.6);     // شب (آبی تیره)

    vec3 currentTint;
    if (uTimeOfDay < 0.5) {
        // صبح تا غروب
        currentTint = mix(dayTint, sunsetTint, uTimeOfDay * 2.0);
    } else {
        // غروب تا شب و صبح
        currentTint = mix(sunsetTint, nightTint, (uTimeOfDay - 0.5) * 2.0);
    }

    // اعمال رنگ زمان روی کل تصویر
    color *= currentTint;

    // 🌟 افکت‌های قبلی (CRT و رنگ) 🌟
    if (uMode == 1) {
        float scanline = sin(TexCoords.y * uResolution.y * 3.14159) * 0.15;
        color -= scanline;

        float vignette = TexCoords.x * TexCoords.y * (1.0 - TexCoords.x) * (1.0 - TexCoords.y);
        vignette = pow(vignette * 15.0, 0.25);
        color *= vignette;

        float offset = 0.002;
        color.r = texture(uScreenTexture, TexCoords + vec2(offset, 0.0)).r * currentTint.r;
        color.b = texture(uScreenTexture, TexCoords - vec2(offset, 0.0)).b * currentTint.b;
    } else if (uMode == 2) {
        color = (color - 0.5) * 1.5 + 0.5;
        float gray = dot(color, vec3(0.299, 0.587, 0.114));
        color = mix(vec3(gray), color, 1.5);
    }

    FragColor = vec4(color, 1.0);
}